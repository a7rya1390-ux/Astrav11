"""Template context used by the SEO tags in base_astra.html."""

from django.conf import settings
from django.templatetags.static import static

SITE_NAME = "ASTRA"
DEFAULT_DESCRIPTION = (
    "Astra is an AI-powered ecosystem: Astra AI assistant, Astragram social feed, news, articles, "
    "projects, music, gallery, events, awards and mini games in one place."
)


def seo(request):
    try:
        logo_path = static("image/astra-logo.jpg")
    except Exception:  # pragma: no cover - a missing manifest entry must never break a page
        logo_path = "/static/image/astra-logo.jpg"
    origin = f"{request.scheme}://{request.get_host()}"
    private_prefixes = (
        "/profile/", "/rank/", "/astragram/messages/", "/astragram/post/",
        "/astra-ai/chat/", "/login/", "/logout/", "/accounts/",
    )
    robots = "noindex,nofollow" if request.path.startswith(private_prefixes) else "index,follow,max-image-preview:large"
    return {
        "seo_site_name": SITE_NAME,
        "seo_default_description": DEFAULT_DESCRIPTION,
        "seo_origin": origin,
        "seo_canonical": f"{origin}{request.path}",
        "seo_default_image": f"{origin}{logo_path}",
        "seo_robots": robots,
        "seo_google_verification": getattr(settings, "GOOGLE_SITE_VERIFICATION", ""),
        "seo_bing_verification": getattr(settings, "BING_SITE_VERIFICATION", ""),
    }
