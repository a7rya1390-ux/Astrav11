"""
Shared upload validators — used across every model that accepts a
user-uploaded file (profile avatar/banner, Astragram posts, Astra Rank
proof images, Gallery photos, Music covers/tracks) to reduce the attack
surface of arbitrary file uploads: oversized files, disguised file
types, and non-image content pretending to be an image.
"""

from django.core.exceptions import ValidationError

MAX_IMAGE_SIZE_MB = 8
MAX_AUDIO_SIZE_MB = 25
MAX_VIDEO_SIZE_MB = 60


def validate_image_file(file):
    if file.size > MAX_IMAGE_SIZE_MB * 1024 * 1024:
        raise ValidationError(f"Image must be smaller than {MAX_IMAGE_SIZE_MB}MB.")

    try:
        from PIL import Image

        file.seek(0)
        img = Image.open(file)
        img.verify()  # Raises if the content isn't actually a valid image.
    except Exception as exc:
        raise ValidationError("This file doesn't look like a valid image.") from exc
    finally:
        file.seek(0)


def validate_audio_file(file):
    if file.size > MAX_AUDIO_SIZE_MB * 1024 * 1024:
        raise ValidationError(f"Audio file must be smaller than {MAX_AUDIO_SIZE_MB}MB.")

    allowed_extensions = (".mp3", ".wav", ".ogg", ".m4a")
    if not file.name.lower().endswith(allowed_extensions):
        raise ValidationError("Unsupported audio format. Use MP3, WAV, OGG, or M4A.")


def validate_video_file(file):
    if file.size > MAX_VIDEO_SIZE_MB * 1024 * 1024:
        raise ValidationError(f"Video file must be smaller than {MAX_VIDEO_SIZE_MB}MB.")

    allowed_extensions = (".mp4", ".webm", ".ogv", ".m4v")
    if not file.name.lower().endswith(allowed_extensions):
        raise ValidationError("Unsupported video format. Use MP4, WebM, OGV, or M4V.")

