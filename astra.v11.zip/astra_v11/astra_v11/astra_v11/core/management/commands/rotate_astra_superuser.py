from getpass import getpass
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.db.models.deletion import CASCADE


class Command(BaseCommand):
    help = "Create one replacement Astra superuser, then remove the old superuser accounts if they have no owned content."

    def handle(self, *args, **options):
        User = get_user_model()
        username = input("New superuser username: ").strip()
        email = input("New superuser email: ").strip()
        password = getpass("New superuser password: ")
        confirm = getpass("Confirm password: ")
        if not username or not password:
            raise CommandError("Username and password are required.")
        if password != confirm:
            raise CommandError("The passwords do not match.")
        if User.objects.filter(username__iexact=username).exists():
            raise CommandError("That username already exists. Choose a new username.")
        candidate = User(username=username, email=email)
        validate_password(password, user=candidate)
        old_users = list(User.objects.filter(is_superuser=True))
        old_ids = [user.pk for user in old_users]
        dependencies = []
        for relation in User._meta.related_objects:
            if not relation.one_to_many and not relation.one_to_one:
                continue
            field = relation.field
            if field.remote_field.on_delete is not CASCADE:
                continue
            model = relation.related_model
            # Profile is account metadata created automatically for every member; it is removed
            # together with that deleted account. Django admin audit rows are reassigned below.
            if model._meta.label_lower in {"accour.profile", "admin.logentry"}:
                continue
            count = model._base_manager.filter(**{f"{field.name}__in": old_ids}).count()
            if count:
                dependencies.append(f"{model._meta.label}: {count}")
        if dependencies:
            raise CommandError(
                "Rotation stopped to protect records owned by old superusers: " + ", ".join(dependencies) + ". "
                "Review and safely reassign or archive those records first; this command will not cascade-delete them."
            )
        names = ", ".join(user.get_username() for user in old_users) or "(none)"
        self.stdout.write(f"Current superusers: {names}")
        if input("Type ROTATE-ASTRA-SUPERUSER to confirm: ").strip() != "ROTATE-ASTRA-SUPERUSER":
            raise CommandError("Confirmation did not match; no changes were made.")
        with transaction.atomic():
            new_user = User.objects.create_superuser(username=username, email=email, password=password)
            # Preserve the admin audit trail while removing old account identities.
            for relation in User._meta.related_objects:
                if not (relation.one_to_many or relation.one_to_one):
                    continue
                field = relation.field
                if field.remote_field.on_delete is not CASCADE:
                    continue
                model = relation.related_model
                if model._meta.label_lower == "admin.logentry" and old_ids:
                    model._base_manager.filter(**{f"{field.name}__in": old_ids}).update(**{field.name: new_user})
            User.objects.filter(is_superuser=True).exclude(pk=new_user.pk).delete()
        remaining = User.objects.filter(is_superuser=True).count()
        if remaining != 1:
            raise CommandError(f"Expected one superuser after rotation; found {remaining}.")
        self.stdout.write(self.style.SUCCESS(f"Created {username}; old superuser accounts removed. Exactly one superuser remains."))
