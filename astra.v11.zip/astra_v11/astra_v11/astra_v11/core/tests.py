from django.test import TestCase
from django.urls import reverse

from newsroom.models import Article

from .models import HomeSlide
from .validators import validate_video_file

from .ai_knowledge import EXTRA_FOLLOW_UPS, EXTRA_RULES
from .views import RULES, _rule_based_reply


class AstraAIRuleTests(TestCase):
    def test_events_rule_and_contextual_follow_up(self):
        reply, topic = _rule_based_reply("How do I create events?")
        self.assertEqual(topic, "events")
        self.assertIn("Django Admin", reply)
        follow_up, follow_topic = _rule_based_reply("Tell me more", previous_topic=topic)
        self.assertEqual(follow_topic, "events")
        self.assertIn("start and end", follow_up)

    def test_awards_rule_explains_points(self):
        reply, topic = _rule_based_reply("How do I earn points in Awards?")
        self.assertEqual(topic, "points")
        self.assertIn("10 points", reply)


class ExistingSitePageSmokeTests(TestCase):
    def test_existing_public_pages_still_render(self):
        for path in (
            "/",
            "/login/",
            "/terms/",
            "/privacy/",
            "/astra-ai/",
            "/about-us/",
            "/support/",
            "/help-center/",
            "/astra-clock/",
            "/astragram/",
            "/news/",
            "/music/",
            "/gallery/",
            "/events/",
            "/awards/",
            "/mini-game/",
        ):
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertEqual(response.status_code, 200)

    def test_protected_pages_redirect_to_login(self):
        for path in ("/profile/", "/rank/"):
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertEqual(response.status_code, 302)
                self.assertIn("/login/", response.url)


class AstraAIv11Tests(TestCase):
    def test_knowledge_pack_is_large_and_well_formed(self):
        topics = [rule[0] for rule in RULES] + [rule[0] for rule in EXTRA_RULES]
        self.assertEqual(len(topics), len(set(topics)), "Every topic name must be unique.")
        self.assertGreaterEqual(sum(len(rule[1]) for rule in EXTRA_RULES), 600)
        for topic, keywords, reply in EXTRA_RULES:
            self.assertTrue(reply, topic)
            for keyword in keywords:
                self.assertEqual(keyword, keyword.lower(), f"{topic}: keywords must be lower case")
        for topic in EXTRA_FOLLOW_UPS:
            self.assertIn(topic, topics)

    def test_new_site_sections_are_understood(self):
        expectations = {
            "How do I add a game?": "mini-game-admin",
            "Tell me about the mini games": "mini-game",
            "how to add news": "news-admin",
            "What is an article?": "article",
            "show me the projects": "project",
            "how do I upload a song": "music-admin",
            "sign in with google": "google-login",
            "give me the site guide": "site-guide",
            "what's new in v11": "whats-new",
        }
        for message, topic in expectations.items():
            with self.subTest(message=message):
                reply, found = _rule_based_reply(message)
                self.assertEqual(found, topic)
                self.assertTrue(reply)

    def test_most_specific_keyword_wins_over_a_greeting(self):
        _, topic = _rule_based_reply("hello, can you tell me about mini games")
        self.assertEqual(topic, "mini-game")
        _, topic = _rule_based_reply("hello")
        self.assertEqual(topic, "greeting")

    def test_small_talk_and_tech_topics(self):
        for message, topic in {
            "how are you?": "how-are-you",
            "tell me a joke": "joke",
            "explain machine learning": "machine-learning",
            "how do I learn robotics": "robotics",
            "teach me git": "git",
            "I feel sad": "feeling-low",
        }.items():
            with self.subTest(message=message):
                self.assertEqual(_rule_based_reply(message)[1], topic)

    def test_site_guide_mentions_every_main_section(self):
        reply, _ = _rule_based_reply("site guide")
        for word in ("Astragram", "News", "Music", "Gallery", "Rank", "Events", "Awards", "Mini Game", "Clock"):
            self.assertIn(word, reply)

    def test_follow_up_works_for_new_topics(self):
        _, topic = _rule_based_reply("how do I add a game?")
        detail, follow_topic = _rule_based_reply("tell me more", previous_topic=topic)
        self.assertEqual(follow_topic, "mini-game-admin")
        self.assertIn("Order", detail)

    def test_unknown_message_gets_the_default_reply(self):
        reply, topic = _rule_based_reply("qwertyuiop asdfghjkl")
        self.assertEqual(topic, "")
        self.assertIn("Mini Games", reply)

    def test_chat_endpoint_answers_with_new_rules(self):
        import json

        response = self.client.post(
            reverse("astra_ai_chat"), data=json.dumps({"message": "how do I add a game?"}), content_type="application/json"
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["topic"], "mini-game-admin")


class VersionAndMenuTests(TestCase):
    def test_footer_and_about_page_show_v11(self):
        home = self.client.get("/")
        self.assertContains(home, "ASTRA v11")
        self.assertNotContains(home, "v8")
        about = self.client.get("/about-us/")
        self.assertContains(about, "ASTRA v11")
        self.assertContains(about, "Astra v11 Released")
        self.assertNotContains(about, "V8")
        self.assertNotContains(about, "v8")

    def test_only_events_and_awards_keep_the_new_badge(self):
        html = self.client.get("/").content.decode()
        self.assertEqual(html.count("nav-badge badge-new"), 2)
        self.assertEqual(html.count("nav-badge badge-soon"), 2)
        for url_name in ("events:list", "awards:leaderboard", "minigames:list"):
            self.assertIn(reverse(url_name), html)

    def test_music_gallery_rank_have_no_new_badge(self):
        for path in ("/music/", "/gallery/", "/rank/"):
            with self.subTest(path=path):
                html = self.client.get(path).content.decode()
                self.assertNotIn("Astra Music <span", html)
                self.assertNotIn("Astra Gallery <span", html)
                self.assertNotIn("Astra Rank <span", html)
                self.assertNotIn("ASTRA RANK <span", html)
                self.assertNotIn("ASTRA MUSIC <span", html)


class SeoTests(TestCase):
    def test_home_page_has_search_engine_tags(self):
        html = self.client.get("/").content.decode()
        self.assertIn('rel="canonical" href="http://testserver/"', html)
        self.assertIn('name="description"', html)
        self.assertIn('property="og:title"', html)
        self.assertIn('name="twitter:card"', html)
        self.assertIn('rel="icon"', html)
        self.assertIn("application/ld+json", html)
        self.assertIn('content="index,follow', html)

    def test_private_and_login_pages_are_noindex(self):
        self.assertIn("noindex", self.client.get("/login/").content.decode())
        from django.contrib.auth import get_user_model
        member = get_user_model().objects.create_user(username="private_page_member", password="A-Strong-Test-Password-2026!")
        self.client.force_login(member)
        self.assertIn("noindex", self.client.get("/profile/").content.decode())
        self.assertIn("noindex", self.client.get("/rank/").content.decode())

    def test_robots_txt(self):
        response = self.client.get("/robots.txt")
        self.assertEqual(response.status_code, 200)
        body = response.content.decode()
        self.assertIn("Sitemap: http://testserver/sitemap.xml", body)
        for path in ("/admin/", "/login/", "/profile/", "/astragram/messages/", "/rank/"):
            self.assertIn(f"Disallow: {path}", body)

    def test_sitemap_uses_the_real_host_and_lists_content(self):
        Article.objects.create(title="Sitemap Article", kind="article", excerpt="x")
        Article.objects.create(title="Hidden One", kind="article", is_published=False)
        response = self.client.get("/sitemap.xml")
        self.assertEqual(response.status_code, 200)
        self.assertIn("xml", response["Content-Type"])
        body = response.content.decode()
        self.assertNotIn("example.com", body)
        self.assertIn("http://testserver/mini-game/", body)
        self.assertIn("http://testserver/terms/", body)
        self.assertIn("http://testserver/privacy/", body)
        self.assertNotIn("http://testserver/rank/", body)
        self.assertIn("http://testserver/news/sitemap-article/", body)
        self.assertNotIn("hidden-one", body)

    def test_google_verification_tag_appears_when_configured(self):
        from django.test import override_settings

        with override_settings(GOOGLE_SITE_VERIFICATION="abc123"):
            html = self.client.get("/").content.decode()
        self.assertIn('name="google-site-verification" content="abc123"', html)


class HomeSliderVideoTests(TestCase):
    def test_image_slide_renders_an_image_and_no_video(self):
        HomeSlide.objects.create(title="Picture Slide", image="home_slides/pic.png")
        html = self.client.get("/").content.decode()
        self.assertIn("Picture Slide", html)
        self.assertIn("home_slides/pic.png", html)
        self.assertNotIn("<video", html)

    def test_video_slide_renders_video_with_autoplay_and_sound_options(self):
        HomeSlide.objects.create(
            title="Video Slide", media_type="video", video="home_slides/videos/clip.mp4",
            image="home_slides/poster.png", video_autoplay=True, video_sound=True,
        )
        html = self.client.get("/").content.decode()
        self.assertIn("<video", html)
        self.assertIn("home_slides/videos/clip.mp4", html)
        self.assertIn('poster="/media/home_slides/poster.png"', html)
        self.assertIn('data-autoplay="1"', html)
        self.assertIn('data-sound="1"', html)
        self.assertIn("slide-sound-btn", html)

    def test_video_slide_can_be_silent_and_manual(self):
        HomeSlide.objects.create(
            title="Quiet Video", media_type="video", video="home_slides/videos/quiet.webm",
            video_autoplay=False, video_sound=False,
        )
        html = self.client.get("/").content.decode()
        self.assertIn('data-autoplay="0"', html)
        self.assertIn('data-sound="0"', html)
        self.assertIn(" muted", html)

    def test_slide_set_to_video_without_a_file_falls_back_to_the_image(self):
        slide = HomeSlide.objects.create(title="No File", media_type="video", image="home_slides/fallback.png")
        self.assertFalse(slide.has_video)
        html = self.client.get("/").content.decode()
        self.assertNotIn("<video", html)
        self.assertIn("home_slides/fallback.png", html)

    def test_admin_validation_requires_a_video_file_for_video_slides(self):
        from django.core.exceptions import ValidationError

        slide = HomeSlide(title="Needs File", media_type="video")
        with self.assertRaises(ValidationError):
            slide.full_clean()
        HomeSlide(title="Image Only", media_type="image").full_clean()

    def test_video_validator_accepts_known_formats_and_rejects_others(self):
        from django.core.exceptions import ValidationError
        from django.core.files.uploadedfile import SimpleUploadedFile

        for name in ("clip.mp4", "clip.WEBM", "clip.ogv", "clip.m4v"):
            validate_video_file(SimpleUploadedFile(name, b"data", content_type="video/mp4"))
        with self.assertRaises(ValidationError):
            validate_video_file(SimpleUploadedFile("script.exe", b"data"))
        too_big = SimpleUploadedFile("big.mp4", b"x")
        too_big.size = 61 * 1024 * 1024
        with self.assertRaises(ValidationError):
            validate_video_file(too_big)

    def test_inactive_slides_are_hidden(self):
        HomeSlide.objects.create(title="Hidden Slide", is_active=False)
        self.assertNotContains(self.client.get("/"), "Hidden Slide")

class AstraAIPersistenceTests(TestCase):
    def test_signed_in_ai_chat_is_saved_and_can_be_reopened(self):
        import json
        from django.contrib.auth import get_user_model
        from .models import AstraAIConversation, AstraAIMessage
        member = get_user_model().objects.create_user(username="ai_history_member", password="Safe-Test-Password-2026!")
        self.client.force_login(member)
        response = self.client.post(
            reverse("astra_ai_chat"),
            data=json.dumps({"message": "How do I use Astra Rank?"}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        conversation_id = response.json()["conversation_id"]
        self.assertIsNotNone(conversation_id)
        self.assertEqual(AstraAIMessage.objects.filter(conversation_id=conversation_id).count(), 2)
        page = self.client.get(reverse("astra_ai"), {"conversation": conversation_id})
        self.assertEqual(page.status_code, 200)
        self.assertContains(page, "How do I use Astra Rank?")
        self.assertContains(page, "Astra Rank")

    def test_ai_rejects_malformed_or_empty_requests(self):
        response = self.client.post(reverse("astra_ai_chat"), data="{bad", content_type="application/json")
        self.assertEqual(response.status_code, 400)
        response = self.client.post(reverse("astra_ai_chat"), data="{}", content_type="application/json")
        self.assertEqual(response.status_code, 400)
