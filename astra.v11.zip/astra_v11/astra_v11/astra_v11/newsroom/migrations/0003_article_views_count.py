from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("newsroom", "0002_article_kind_topic_links")]
    operations = [
        migrations.AddField(
            model_name="article",
            name="views_count",
            field=models.PositiveIntegerField(db_index=True, default=0, editable=False),
        ),
    ]
