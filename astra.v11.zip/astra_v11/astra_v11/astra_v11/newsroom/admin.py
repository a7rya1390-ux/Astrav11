from django.contrib import admin
from django.utils.html import format_html

from .models import Article


@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ("title", "kind", "category", "views_count", "is_featured", "is_published", "created_at")
    list_editable = ("is_featured", "is_published")
    list_filter = ("kind", "category", "is_featured", "is_published", "created_at")
    search_fields = ("title", "excerpt", "body", "topic")
    prepopulated_fields = {"slug": ("title",)}
    radio_fields = {"kind": admin.HORIZONTAL}
    readonly_fields = ("views_count", "created_at", "image_preview")
    fieldsets = (
        ("Step 1: What do you want to add?", {
            "description": "Choose News, Article or Project. The form below shows the fields needed for that type.",
            "fields": ("kind",),
        }),
        ("Content", {"classes": ("astra-always",), "fields": ("title", "slug", "topic", "excerpt", "body", "image", "image_preview")}),
        ("News settings", {"classes": ("astra-kind-news",), "fields": ("category", "is_featured")}),
        ("Project links", {"classes": ("astra-kind-project",), "fields": ("project_url", "source_url")}),
        ("Publishing and analytics", {"classes": ("astra-always",), "fields": ("is_published", "views_count", "created_at")}),
    )

    @admin.display(description="Image preview")
    def image_preview(self, obj):
        if not obj or not obj.image:
            return "No image uploaded"
        return format_html('<a href="{}" target="_blank" rel="noopener"><img src="{}" style="max-width:320px;max-height:220px;object-fit:contain;border-radius:8px" /></a>', obj.image.url, obj.image.url)

    class Media:
        js = ("js/astra-admin-news.js",)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        if "kind" in form.base_fields:
            form.base_fields["kind"].label = "What are you adding?"
            form.base_fields["kind"].initial = request.GET.get("kind") or Article.Kind.NEWS
        return form
