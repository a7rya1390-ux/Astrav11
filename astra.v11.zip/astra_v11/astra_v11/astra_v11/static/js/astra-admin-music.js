/*
 * ASTRA v10 - Django Admin helper for Astra Music.
 * Turns the single "Category" list on the Song form into step-by-step choices:
 * Language -> Mood -> Style (as deep as the categories you created).
 * The original list stays in the page (hidden) and always receives the final choice,
 * so saving works exactly as before even if this script is disabled.
 */
(function (root) {
    "use strict";

    var SEP = " \u203A ";

    function buildTree(options) {
        var tree = { name: "", value: "", children: {}, order: [] };
        options.forEach(function (opt) {
            if (!opt.value) { return; }
            var node = tree;
            opt.label.split(SEP).forEach(function (part) {
                part = part.trim();
                if (!node.children[part]) {
                    node.children[part] = { name: part, value: "", children: {}, order: [] };
                    node.order.push(part);
                }
                node = node.children[part];
            });
            node.value = String(opt.value);
        });
        return tree;
    }

    function nodeAt(tree, path) {
        var node = tree;
        for (var i = 0; i < path.length; i++) {
            node = node.children[path[i]];
            if (!node) { return null; }
        }
        return node;
    }

    function findPath(tree, value, prefix) {
        prefix = prefix || [];
        for (var i = 0; i < tree.order.length; i++) {
            var name = tree.order[i];
            var child = tree.children[name];
            var path = prefix.concat([name]);
            if (child.value && child.value === String(value)) { return path; }
            var deeper = findPath(child, value, path);
            if (deeper) { return deeper; }
        }
        return null;
    }

    function resolveValue(tree, path) {
        var node = nodeAt(tree, path);
        return node && node.value ? node.value : "";
    }

    var api = { buildTree: buildTree, nodeAt: nodeAt, findPath: findPath, resolveValue: resolveValue, SEP: SEP };
    if (typeof module !== "undefined" && module.exports) { module.exports = api; }

    if (typeof document === "undefined") { return; }

    function init() {
        var select = document.getElementById("id_category");
        if (!select || select.getAttribute("data-astra-cascade")) { return; }
        select.setAttribute("data-astra-cascade", "1");

        var box = document.createElement("div");
        box.className = "astra-cascade";
        select.parentNode.insertBefore(box, select.nextSibling);
        select.style.display = "none";

        var path = [];
        var internal = false;
        var scheduled = false;

        function readOptions() {
            return Array.prototype.map.call(select.options, function (o) {
                return { value: o.value, label: o.text };
            });
        }

        function render() {
            var tree = buildTree(readOptions());
            if (!internal) {
                path = select.value ? (findPath(tree, select.value) || []) : [];
            }
            box.innerHTML = "";

            var node = tree;
            var depth = 0;
            while (node && node.order.length) {
                box.appendChild(makeStep(tree, node, depth));
                var picked = path[depth];
                node = picked ? node.children[picked] : null;
                depth += 1;
            }
            if (!tree.order.length) {
                var hint = document.createElement("span");
                hint.className = "astra-cascade-hint";
                hint.textContent = "No categories yet. Use the + button to create your first one.";
                box.appendChild(hint);
            }
        }

        function makeStep(tree, node, depth) {
            var step = document.createElement("select");
            step.className = "astra-cascade-step";
            var labels = ["Language / group", "Mood / type", "Style", "Sub-style"];
            var blank = document.createElement("option");
            blank.value = "";
            blank.textContent = depth === 0 ? "\u2014 No category \u2014" : "\u2014 " + labels[Math.min(depth, 3)] + " (optional) \u2014";
            step.appendChild(blank);
            node.order.forEach(function (name) {
                var o = document.createElement("option");
                o.value = name;
                o.textContent = name;
                step.appendChild(o);
            });
            step.value = path[depth] || "";
            step.addEventListener("change", function () {
                path = path.slice(0, depth);
                if (step.value) { path.push(step.value); }
                internal = true;
                select.value = resolveValue(tree, path);
                select.dispatchEvent(new Event("change", { bubbles: true }));
                render();
                internal = false;
            });
            return step;
        }

        render();

        // The "+" popup adds a new option to the hidden list; rebuild the steps when that happens.
        if (typeof MutationObserver !== "undefined") {
            new MutationObserver(function () {
                if (scheduled || internal) { return; }
                scheduled = true;
                setTimeout(function () { scheduled = false; render(); }, 0);
            }).observe(select, { childList: true });
        }
        select.addEventListener("change", function () { if (!internal) { render(); } });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})(typeof window !== "undefined" ? window : this);
