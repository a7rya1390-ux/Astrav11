// ==========================
// PAGE REVEAL
// ==========================

window.addEventListener("load", () => {

    document
        .querySelectorAll(
            ".help-card,.faq-item,.contact-help"
        )
        .forEach((el, index) => {

            setTimeout(() => {

                el.classList.add("show");

            }, index * 100);

        });

});

// ==========================
// SEARCH
// ==========================

const searchInput =
    document.querySelector(
        ".search-box input"
    );

const helpCards =
    document.querySelectorAll(
        ".help-card"
    );

searchInput.addEventListener(
    "keyup",
    () => {

        const value =
            searchInput.value
                .toLowerCase();

        helpCards.forEach(card => {

            const text =
                card.innerText
                    .toLowerCase();

            if (text.includes(value)) {

                card.style.display =
                    "block";

            } else {

                card.style.display =
                    "none";

            }

        });

    });

// ==========================
// FAQ ACCORDION
// ==========================

document
    .querySelectorAll(".faq-item")
    .forEach(item => {

        const answer =
            item.querySelector("p");

        answer.style.maxHeight =
            "0px";

        answer.style.overflow =
            "hidden";

        answer.style.transition =
            ".3s";

        item.addEventListener(
            "click",
            () => {

                if (answer.style.maxHeight === "0px") {

                    answer.style.maxHeight =
                        "200px";

                } else {

                    answer.style.maxHeight =
                        "0px";

                }

            });

    });

// ==========================
// CARD HOVER GLOW
// ==========================

document
    .querySelectorAll(".help-card")
    .forEach(card => {

        card.addEventListener(
            "mouseenter",
            () => {

                card.style.boxShadow =
                    "0 0 30px rgba(245,193,108,.15)";

            });

        card.addEventListener(
            "mouseleave",
            () => {

                card.style.boxShadow =
                    "none";

            });

    });