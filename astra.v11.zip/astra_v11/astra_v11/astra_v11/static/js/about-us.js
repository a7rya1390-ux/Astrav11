// ==========================
// REVEAL ANIMATION
// ==========================

window.addEventListener("load", () => {

    document
        .querySelectorAll(
            ".content-card,.value-card,.timeline-item,.stat-card,.info-box,.contact-shortcut"
        )
        .forEach((el, index) => {

            setTimeout(() => {

                el.classList.add("show");

            }, index * 100);

        });

});

// ==========================
// COUNTER ANIMATION
// ==========================

const counters =
    document.querySelectorAll(
        ".stat-card h3"
    );

const runCounter = () => {

    counters.forEach(counter => {

        const text =
            counter.innerText;

        if (text === "5") {

            animate(counter, 5);

        }

    });

};

function animate(el, target) {

    let count = 0;

    const timer = setInterval(() => {

        count++;

        el.innerText = count;

        if (count >= target) {

            clearInterval(timer);

        }

    }, 150);

}

runCounter();

// ==========================
// TIMELINE HOVER
// ==========================

document
    .querySelectorAll(
        ".timeline-item"
    )
    .forEach(item => {

        item.addEventListener(
            "mouseenter",
            () => {

                item.style.transform =
                    "translateX(10px)";

            });

        item.addEventListener(
            "mouseleave",
            () => {

                item.style.transform =
                    "translateX(0px)";

            });

    });

// ==========================
// VALUE CARDS EFFECT
// ==========================

document
    .querySelectorAll(
        ".value-card"
    )
    .forEach(card => {

        card.addEventListener(
            "mouseenter",
            () => {

                card.style.boxShadow =
                    "0 0 35px rgba(245,193,108,.18)";

            });

        card.addEventListener(
            "mouseleave",
            () => {

                card.style.boxShadow =
                    "none";

            });

    });