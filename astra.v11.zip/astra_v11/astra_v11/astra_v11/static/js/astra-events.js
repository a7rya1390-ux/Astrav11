(function () {
    function celebrate(container, amount) {
        if (!container || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
        var count = amount || 100;
        var fragment = document.createDocumentFragment();
        for (var i = 0; i < count; i += 1) {
            var piece = document.createElement("span");
            piece.className = "astra-confetti-piece";
            piece.style.left = (Math.random() * 100) + "%";
            piece.style.background = ["#F5C16C", "#FCE8B2", "#D7B5FF", "#A9E8D0", "#FFFFFF"][i % 5];
            piece.style.animationDelay = (Math.random() * 0.8) + "s";
            piece.style.animationDuration = (2.4 + Math.random() * 1.8) + "s";
            piece.style.setProperty("--drift", ((Math.random() - 0.5) * 260) + "px");
            fragment.appendChild(piece);
            window.setTimeout(function (node) { node.remove(); }, 5000, piece);
        }
        container.appendChild(fragment);
    }

    document.addEventListener("DOMContentLoaded", function () {
        var confettiLayer = document.getElementById("eventConfetti");
        document.querySelectorAll(".event-card-live [data-confetti='true']").forEach(function (button) {
            button.addEventListener("click", function () { celebrate(confettiLayer, 130); });
        });

        // A live event celebrates automatically when the page opens.
        if (document.querySelector(".event-card-live [data-confetti='true']")) {
            window.setTimeout(function () { celebrate(confettiLayer, 90); }, 350);
        }

        document.querySelectorAll(".event-countdown[data-starts-at]").forEach(function (node) {
            var target = new Date(node.dataset.startsAt).getTime();
            function updateCountdown() {
                var distance = target - Date.now();
                if (!Number.isFinite(distance)) { node.textContent = "Scheduled celebration"; return; }
                if (distance <= 0) { node.textContent = "Starting now — refresh to join the celebration"; return; }
                var days = Math.floor(distance / 86400000);
                var hours = Math.floor((distance % 86400000) / 3600000);
                var minutes = Math.floor((distance % 3600000) / 60000);
                node.textContent = days + "d  " + hours + "h  " + minutes + "m until the celebration";
            }
            updateCountdown();
            window.setInterval(updateCountdown, 60000);
        });
    });
})();
