// ==========================
// LIVE CLOCK
// ==========================

function updateClock() {

    const now = new Date();

    // MAIN TIME

    document.getElementById("liveTime")
        .innerHTML =
        now.toLocaleTimeString();

    // GREGORIAN DATE

    document.getElementById("gregorianDate")
        .innerHTML =
        now.toLocaleDateString(
            "en-US",
            {
                year: "numeric",
                month: "long",
                day: "numeric"
            }
        );

    // HIJRI DATE

    document.getElementById("hijriDate")
        .innerHTML =
        new Intl.DateTimeFormat(
            "en-TN-u-ca-islamic",
            {
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        ).format(now);

    document.getElementById("jalaliDate")
        .innerHTML =
        new Intl.DateTimeFormat(
            "fa-IR-u-ca-persian",
            {
                year: "numeric",
                month: "long",
                day: "numeric"
            }
        ).format(new Date());

    // UTC

    document.getElementById("utcTime")
        .innerHTML =
        now.toUTCString();

    // WORLD CLOCKS

    document.getElementById("newYorkTime")
        .innerHTML =
        now.toLocaleTimeString(
            "en-US",
            {
                timeZone:
                    "America/New_York"
            }
        );

    document.getElementById("tehranTime")
        .innerHTML =
        now.toLocaleTimeString(
            "en-US",
            {
                timeZone:
                    "Asia/Tehran"
            }
        );

    document.getElementById("riyadhTime")
        .innerHTML =
        now.toLocaleTimeString(
            "en-US",
            {
                timeZone:
                    "Asia/Riyadh"
            }
        );

    document.getElementById("madridTime")
        .innerHTML =
        now.toLocaleTimeString(
            "en-US",
            {
                timeZone:
                    "Europe/Madrid"
            }
        );

    document.getElementById("tokyoTime")
        .innerHTML =
        now.toLocaleTimeString(
            "en-US",
            {
                timeZone:
                    "Asia/Tokyo"
            }
        );

}

updateClock();

setInterval(
    updateClock,
    1000
);