// ==========================
// SCROLL REVEAL
// ==========================

const observer = new IntersectionObserver(

    (entries) => {

        entries.forEach((entry) => {

            if (entry.isIntersecting) {

                entry.target.classList.add("show");

            }

        });

    },

    {
        threshold: 0.15
    }

);

document
    .querySelectorAll(
        ".card,.why-card,.stat-box"
    )
    .forEach((el) => {

        observer.observe(el);

    });

// ==========================
// COUNTER ANIMATION
// ==========================

const counters =
    document.querySelectorAll(".stat-box h3");

const speed = 100;

counters.forEach(counter => {

    const updateCount = () => {

        const target =
            parseInt(
                counter.innerText
            );

        const count =
            parseInt(
                counter.getAttribute("data-count")
            ) || 0;

        const increment =
            target / speed;

        if (count < target) {

            counter.setAttribute(
                "data-count",
                Math.ceil(count + increment)
            );

            counter.innerText =
                Math.ceil(count + increment);

            setTimeout(
                updateCount,
                20
            );

        } else {

            counter.innerText =
                target + "+";

        }

    };

    updateCount();

});

// ==========================
// NAVBAR SCROLL EFFECT
// ==========================

window.addEventListener(
    "scroll",
    () => {

        const navbar =
            document.querySelector(".navbar");

        if (window.scrollY > 50) {

            navbar.style.background =
                "rgba(5,8,22,.95)";

            navbar.style.boxShadow =
                "0 10px 30px rgba(0,0,0,.35)";

        } else {

            navbar.style.background =
                "rgba(5,8,22,.75)";

            navbar.style.boxShadow =
                "none";

        }

    }
);

// ==========================
// BUTTON GLOW
// ==========================

document
    .querySelectorAll(
        ".primary-btn,.start-btn"
    )
    .forEach(btn => {

        btn.addEventListener(
            "mouseenter",
            () => {

                btn.style.boxShadow =
                    "0 0 25px rgba(245,193,108,.6)";

            });

        btn.addEventListener(
            "mouseleave",
            () => {

                btn.style.boxShadow =
                    "none";

            });

    });

// ==========================
// HERO FADE-IN
// ==========================

window.addEventListener(
    "load",
    () => {

        const heroContent =
            document.querySelector(".hero-content");

        if (heroContent) {
            heroContent.style.opacity = "1";
            heroContent.style.transform = "translateY(0)";
        }

    });

