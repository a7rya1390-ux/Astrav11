/*
 * ASTRA v10 - Django Admin helper for Astra News.
 * Step 1 on the form is choosing News, Article or Project. This script then shows only the
 * fields that matter for that choice and renames the labels (for example "Summary" for an article).
 * If the script cannot run, every field simply stays visible and saving still works.
 */
(function () {
    "use strict";

    var LABELS = {
        news: { excerpt: "Excerpt", body: "Body", title: "Title" },
        article: { excerpt: "Summary of the article", body: "Full article", title: "Article title" },
        project: { excerpt: "Short description", body: "Full description", title: "Project name" }
    };

    function currentKind() {
        var checked = document.querySelector('input[name="kind"]:checked');
        if (checked) { return checked.value; }
        var select = document.querySelector('select[name="kind"]');
        return select ? select.value : "news";
    }

    function setLabel(fieldName, text) {
        var label = document.querySelector('label[for="id_' + fieldName + '"]');
        if (label) { label.textContent = text + ":"; }
    }

    function setVisible(el, visible) {
        if (el) { el.style.display = visible ? "" : "none"; }
    }

    function apply() {
        var kind = currentKind();
        var labels = LABELS[kind] || LABELS.news;
        setLabel("excerpt", labels.excerpt);
        setLabel("body", labels.body);
        setLabel("title", labels.title);

        ["news", "article", "project"].forEach(function (name) {
            document.querySelectorAll("fieldset.astra-kind-" + name).forEach(function (fs) {
                setVisible(fs, kind === name);
            });
        });
        setVisible(document.querySelector(".form-row.field-topic"), kind === "article");
    }

    function init() {
        document.querySelectorAll('input[name="kind"], select[name="kind"]').forEach(function (input) {
            input.addEventListener("change", apply);
        });
        apply();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
