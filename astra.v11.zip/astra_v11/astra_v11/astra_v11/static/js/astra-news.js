// ==========================
// PAGE REVEAL
// ==========================

window.addEventListener("load", () => {

    document
        .querySelectorAll(
            ".news-card,.trend-card,.featured-card"
        )
        .forEach((el, index) => {

            setTimeout(() => {

                el.classList.add("show");

            }, index * 120);

        });

});

// ==========================
// SEARCH FILTER
// ==========================

const searchInput =
    document.querySelector(
        ".search-box input"
    );

const newsCards =
    document.querySelectorAll(
        ".news-card"
    );

if (searchInput) {

    searchInput.addEventListener(
        "keyup",
        () => {

            const value =
                searchInput.value
                    .toLowerCase();

            newsCards.forEach(card => {

                const text =
                    card.innerText
                        .toLowerCase();

                if (text.includes(value)) {

                    card.style.display =
                        "block";

                } else {

                    card.style.display =
                        "none";

                }

            });

        });

}

// ==========================
// READ MORE EFFECT
// ==========================

document
    .querySelectorAll(
        ".news-card button,.featured-content button"
    )
    .forEach(btn => {

        btn.addEventListener(
            "click",
            () => {

                btn.innerText =
                    "Opening...";

                setTimeout(() => {

                    btn.innerText =
                        "Read More";

                }, 1200);

            });

    });

// ==========================
// TRENDING GLOW
// ==========================

document
    .querySelectorAll(".trend-card")
    .forEach(card => {

        card.addEventListener(
            "mouseenter",
            () => {

                card.style.boxShadow =
                    "0 0 25px rgba(139,92,246,.25)";

            });

        card.addEventListener(
            "mouseleave",
            () => {

                card.style.boxShadow =
                    "none";

            });

    });

// ==========================
// HEADER PARALLAX
// ==========================

window.addEventListener(
    "scroll",
    () => {

        const header =
            document.querySelector(
                ".news-header"
            );

        const offset =
            window.scrollY * 0.25;

        header.style.transform =
            `translateY(${offset}px)`;

    });