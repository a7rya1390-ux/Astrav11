from datetime import datetime, time, timedelta

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone
from django.db.models import Sum

from astragram.models import Comment, Like, Post

from .models import CompetitionAward, DailyChampion, MonthlyChampion, ScoreEntry
from .services import (
    COMMENT_POINTS,
    LIKE_POINTS,
    POST_POINTS,
    record_comment_score,
    record_like_score,
    record_post_score,
    remove_like_score,
    finalize_competitions,
    finalize_closed_days,
    finalize_closed_period_awards,
)

User = get_user_model()


class AstraAwardScoringTests(TestCase):
    def setUp(self):
        self.author = User.objects.create_user(username="post_author", password="Secure-test-password-123!")
        self.member = User.objects.create_user(username="community_member", password="Secure-test-password-123!")
        self.post = Post.objects.create(author=self.author, caption="Astra community post")

    def test_post_receives_points(self):
        self.assertTrue(record_post_score(self.post))
        self.assertEqual(ScoreEntry.objects.get(source_key=f"post:{self.post.pk}").points, POST_POINTS)

    def test_like_points_are_not_repeated_by_toggling(self):
        like = Like.objects.create(post=self.post, user=self.member)
        record_like_score(like)
        score = ScoreEntry.objects.get(source_key=f"like:{self.post.pk}:{self.member.pk}")
        self.assertEqual(score.points, LIKE_POINTS)
        remove_like_score(like)
        score.refresh_from_db()
        self.assertEqual(score.points, 0)
        like.delete()
        new_like = Like.objects.create(post=self.post, user=self.member)
        record_like_score(new_like)
        score.refresh_from_db()
        self.assertEqual(score.points, LIKE_POINTS)
        self.assertEqual(ScoreEntry.objects.filter(source_key=f"like:{self.post.pk}:{self.member.pk}").count(), 1)

    def test_repeated_comments_on_same_post_only_score_once(self):
        first = Comment.objects.create(post=self.post, user=self.member, text="First comment")
        second = Comment.objects.create(post=self.post, user=self.member, text="Another thought")
        record_comment_score(first)
        record_comment_score(second)
        self.assertEqual(
            ScoreEntry.objects.filter(source_key=f"comment:{self.post.pk}:{self.member.pk}").count(),
            1,
        )

    def test_self_interactions_do_not_award_points(self):
        like = Like.objects.create(post=self.post, user=self.author)
        record_like_score(like)
        comment = Comment.objects.create(post=self.post, user=self.author, text="My own comment")
        record_comment_score(comment)
        self.assertFalse(ScoreEntry.objects.filter(kind__in=[ScoreEntry.Kind.LIKE, ScoreEntry.Kind.COMMENT]).exists())

    def test_comment_points_go_to_post_owner(self):
        comment = Comment.objects.create(post=self.post, user=self.member, text="Great work!")
        record_comment_score(comment)
        self.assertEqual(
            ScoreEntry.objects.get(source_key=f"comment:{self.post.pk}:{self.member.pk}").points,
            COMMENT_POINTS,
        )

    def test_awards_page_renders(self):
        record_post_score(self.post)
        response = self.client.get("/awards/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Monthly Leaderboard")


class AstraAwardFinalizationTests(TestCase):
    def setUp(self):
        self.winner = User.objects.create_user(username="monthly_winner", password="A-Long-Unique-Password-2026!")

    def test_closed_month_and_daily_champion_are_saved_once(self):
        today = timezone.localdate()
        last_month_day = today.replace(day=1) - timedelta(days=1)
        created_at = timezone.make_aware(datetime.combine(last_month_day, time(hour=12)))
        entry = ScoreEntry.objects.create(
            user=self.winner,
            actor=self.winner,
            kind=ScoreEntry.Kind.POST,
            points=10,
            source_key="historical-month-entry",
        )
        ScoreEntry.objects.filter(pk=entry.pk).update(created_at=created_at)

        first_run = finalize_competitions(today=today)
        second_run = finalize_competitions(today=today)

        self.assertEqual(first_run["days"], 1)
        self.assertEqual(first_run["months"], 1)
        self.assertGreaterEqual(first_run["awards"], 1)
        self.assertEqual(second_run, {"days": 0, "months": 0, "awards": 0})
        self.assertEqual(
            MonthlyChampion.objects.get(year=last_month_day.year, month=last_month_day.month).points,
            10,
        )
        self.assertEqual(ScoreEntry.objects.filter(user=self.winner).aggregate(total=Sum("points"))["total"], 10)

    def test_zero_point_like_does_not_create_daily_champion(self):
        today = timezone.localdate()
        yesterday = today - timedelta(days=1)
        created_at = timezone.make_aware(datetime.combine(yesterday, time(hour=12)))
        entry = ScoreEntry.objects.create(
            user=self.winner,
            actor=self.winner,
            kind=ScoreEntry.Kind.LIKE,
            points=0,
            source_key="removed-like-entry",
        )
        ScoreEntry.objects.filter(pk=entry.pk).update(created_at=created_at)
        self.assertEqual(finalize_closed_days(today=today), 0)
        self.assertFalse(DailyChampion.objects.filter(award_date=yesterday).exists())


class AstraAwardClaimTests(TestCase):
    def test_closed_period_award_does_not_add_points_and_claim_is_one_time(self):
        from django.db.models import Sum
        from datetime import date
        user = User.objects.create_user(username="award_winner", password="Safe-Test-Password-2026!")
        award = CompetitionAward.objects.create(period_type="monthly", period_start=date(2026, 1, 1), period_end=date(2026, 1, 31), user=user, title="Astra Monthly Champion", score_at_close=25)
        self.assertEqual(ScoreEntry.objects.filter(user=user).aggregate(total=Sum("points"))["total"], None)
        self.client.force_login(user)
        response = self.client.post(f"/awards/claim/{award.pk}/")
        self.assertEqual(response.status_code, 302)
        award.refresh_from_db()
        self.assertIsNotNone(award.claimed_at)
        first_claim = award.claimed_at
        self.client.post(f"/awards/claim/{award.pk}/")
        award.refresh_from_db()
        self.assertEqual(award.claimed_at, first_claim)
