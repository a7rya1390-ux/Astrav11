from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
import core.validators


class Migration(migrations.Migration):
    dependencies = [
        ("awards", "0001_initial"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.AlterField(model_name="scoreentry", name="kind", field=models.CharField(choices=[("post", "Published post"), ("like", "Received like"), ("comment", "Received comment"), ("rank", "Approved Astra Rank achievement")], max_length=12)),
        migrations.AlterField(model_name="dailychampion", name="points_awarded", field=models.PositiveSmallIntegerField(default=0, help_text="Legacy field retained for compatibility; winning a period no longer adds points.")),
        migrations.CreateModel(
            name="CompetitionAward",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("period_type", models.CharField(choices=[("daily", "Daily"), ("weekly", "Weekly"), ("monthly", "Monthly"), ("quarterly", "Quarterly"), ("yearly", "Yearly")], db_index=True, max_length=12)),
                ("period_start", models.DateField(db_index=True)),
                ("period_end", models.DateField()),
                ("title", models.CharField(max_length=120)),
                ("icon", models.CharField(default="🏆", max_length=12)),
                ("image", models.ImageField(blank=True, null=True, upload_to="awards/trophies/", validators=[core.validators.validate_image_file])),
                ("score_at_close", models.PositiveIntegerField(default=0)),
                ("awarded_at", models.DateTimeField(default=django.utils.timezone.now)),
                ("claimed_at", models.DateTimeField(blank=True, null=True)),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="astra_competition_awards", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-period_end", "period_type", "user__username"]},
        ),
        migrations.AddConstraint(model_name="competitionaward", constraint=models.UniqueConstraint(fields=("period_type", "period_start", "user"), name="unique_period_award_per_user")),
        migrations.AddIndex(model_name="competitionaward", index=models.Index(fields=["user", "claimed_at"], name="awards_comp_user_id_2ebcaf_idx")),
    ]
