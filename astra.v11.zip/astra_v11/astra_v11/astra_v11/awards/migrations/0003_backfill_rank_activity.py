from django.db import migrations


def backfill_approved_rank_activity(apps, schema_editor):
    Submission = apps.get_model("rank", "Submission")
    ScoreEntry = apps.get_model("awards", "ScoreEntry")
    alias = schema_editor.connection.alias
    for submission in Submission.objects.using(alias).filter(status="approved").iterator():
        entry, created = ScoreEntry.objects.using(alias).get_or_create(
            source_key=f"rank:{submission.pk}",
            defaults={
                "user_id": submission.user_id,
                "actor_id": submission.user_id,
                "kind": "rank",
                "points": submission.points,
            },
        )
        if created:
            ScoreEntry.objects.using(alias).filter(pk=entry.pk).update(created_at=submission.created_at)


class Migration(migrations.Migration):
    dependencies = [
        ("awards", "0002_rank_scores_and_period_awards"),
        ("rank", "0003_rank_period_prizes"),
    ]
    operations = [migrations.RunPython(backfill_approved_rank_activity, migrations.RunPython.noop)]
