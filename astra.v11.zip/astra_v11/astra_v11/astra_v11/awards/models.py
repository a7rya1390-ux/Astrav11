from django.conf import settings
from django.db import models
from django.utils import timezone
from core.validators import validate_image_file


class ScoreEntry(models.Model):
    class Kind(models.TextChoices):
        POST = "post", "Published post"
        LIKE = "like", "Received like"
        COMMENT = "comment", "Received comment"
        RANK = "rank", "Approved Astra Rank achievement"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="astra_score_entries")
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="astra_score_actions")
    kind = models.CharField(max_length=12, choices=Kind.choices)
    points = models.PositiveSmallIntegerField()
    source_key = models.CharField(max_length=120, unique=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["user", "created_at"], name="awards_scor_user_id_b43dee_idx"), models.Index(fields=["kind", "created_at"], name="awards_scor_kind_707073_idx")]

    def __str__(self): return f"{self.user} +{self.points} ({self.get_kind_display()})"


class DailyChampion(models.Model):
    award_date = models.DateField(db_index=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="astra_daily_awards")
    points_awarded = models.PositiveSmallIntegerField(default=0, help_text="Legacy field retained for compatibility; winning a period no longer adds points.")
    score_at_close = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ["-award_date", "user__username"]
        constraints = [models.UniqueConstraint(fields=["award_date", "user"], name="unique_daily_champion_user")]
    def __str__(self): return f"{self.user} — Daily Champion ({self.award_date})"


class MonthlyChampion(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="astra_monthly_awards")
    year = models.PositiveSmallIntegerField()
    month = models.PositiveSmallIntegerField()
    points = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ["-year", "-month", "user__username"]
        constraints = [models.UniqueConstraint(fields=["year", "month", "user"], name="unique_monthly_champion_user")]
    def __str__(self): return f"{self.user} — {self.year}-{self.month:02d} Champion"


class CompetitionAward(models.Model):
    class Period(models.TextChoices):
        DAILY = "daily", "Daily"
        WEEKLY = "weekly", "Weekly"
        MONTHLY = "monthly", "Monthly"
        QUARTERLY = "quarterly", "Quarterly"
        YEARLY = "yearly", "Yearly"

    period_type = models.CharField(max_length=12, choices=Period.choices, db_index=True)
    period_start = models.DateField(db_index=True)
    period_end = models.DateField()
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="astra_competition_awards")
    title = models.CharField(max_length=120)
    icon = models.CharField(max_length=12, default="🏆")
    image = models.ImageField(upload_to="awards/trophies/", blank=True, null=True, validators=[validate_image_file])
    score_at_close = models.PositiveIntegerField(default=0)
    awarded_at = models.DateTimeField(default=timezone.now)
    claimed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-period_end", "period_type", "user__username"]
        constraints = [models.UniqueConstraint(fields=["period_type", "period_start", "user"], name="unique_period_award_per_user")]
        indexes = [models.Index(fields=["user", "claimed_at"], name="awards_comp_user_id_2ebcaf_idx")]

    def __str__(self): return f"{self.user} — {self.title} ({self.period_start})"
