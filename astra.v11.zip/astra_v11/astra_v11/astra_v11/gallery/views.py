from django.shortcuts import render

from .models import GalleryPhoto


def gallery_list(request):
    photos = GalleryPhoto.objects.filter(is_published=True)
    return render(request, "gallery/gallery_list.html", {"photos": photos})
