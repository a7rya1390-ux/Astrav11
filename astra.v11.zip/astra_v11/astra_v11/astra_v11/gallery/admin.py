from django.contrib import admin
from django.utils.html import format_html

from .models import GalleryPhoto


@admin.register(GalleryPhoto)
class GalleryPhotoAdmin(admin.ModelAdmin):
    list_display = ("thumbnail", "title", "location", "order", "is_published", "created_at")
    list_display_links = ("thumbnail", "title")
    list_editable = ("order", "is_published")
    list_filter = ("is_published", "created_at")
    search_fields = ("title", "location")
    readonly_fields = ("created_at", "image_preview")
    fields = ("title", "image", "image_preview", "location", "order", "is_published", "created_at")

    @admin.display(description="Photo")
    def thumbnail(self, obj):
        if not obj.image:
            return "—"
        return format_html('<img src="{}" alt="" style="width:58px;height:58px;object-fit:cover;border-radius:8px" />', obj.image.url)

    @admin.display(description="Uploaded photo preview")
    def image_preview(self, obj):
        if not obj or not obj.image:
            return "No photo uploaded"
        return format_html('<a href="{}" target="_blank" rel="noopener"><img src="{}" style="max-width:420px;max-height:300px;object-fit:contain;border-radius:9px" /></a>', obj.image.url, obj.image.url)
