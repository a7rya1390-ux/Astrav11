from django.contrib import admin
from django.utils.html import format_html

from .models import Game


@admin.register(Game)
class GameAdmin(admin.ModelAdmin):
    list_display = ("preview", "title", "button_text", "order", "is_published", "created_at")
    list_display_links = ("preview", "title")
    list_editable = ("order", "is_published")
    list_filter = ("is_published",)
    search_fields = ("title", "description")
    prepopulated_fields = {"slug": ("title",)}
    readonly_fields = ("created_at", "image_preview")
    fieldsets = (
        ("Game", {"fields": ("title", "slug", "description", "image", "image_preview")}),
        ("Play button", {"fields": ("button_text", "game_link")}),
        ("Visibility", {"fields": ("order", "is_published", "created_at")}),
    )

    @admin.display(description="Cover")
    def preview(self, obj):
        if obj.image:
            return format_html(
                '<img src="{}" alt="" style="width:54px;height:54px;object-fit:cover;border-radius:10px;">',
                obj.image.url,
            )
        return "—"

    @admin.display(description="Uploaded cover preview")
    def image_preview(self, obj):
        if not obj or not obj.image:
            return "No cover image uploaded"
        return format_html(
            '<a href="{}" target="_blank" rel="noopener"><img src="{}" style="max-width:420px;max-height:300px;object-fit:contain;border-radius:9px" /></a>',
            obj.image.url,
            obj.image.url,
        )
