from django.core.exceptions import ValidationError
from django.test import TestCase
from django.urls import reverse

from .models import Game, validate_game_link


class MiniGameTests(TestCase):
    def test_empty_page_renders(self):
        response = self.client.get(reverse("minigames:list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "No games yet")

    def test_published_game_shows_card_with_play_button_and_link(self):
        Game.objects.create(
            title="Backrooms",
            description="Explore the endless rooms.",
            button_text="Play now",
            game_link="https://example.com/backrooms/",
        )
        response = self.client.get(reverse("minigames:list"))
        self.assertContains(response, "Backrooms")
        self.assertContains(response, "Explore the endless rooms.")
        self.assertContains(response, 'href="https://example.com/backrooms/"')
        self.assertContains(response, "Play now")

    def test_unpublished_game_is_hidden(self):
        Game.objects.create(title="Secret Draft", game_link="https://example.com/x", is_published=False)
        response = self.client.get(reverse("minigames:list"))
        self.assertNotContains(response, "Secret Draft")

    def test_search_filters_games(self):
        Game.objects.create(title="Maze Runner", game_link="https://example.com/maze")
        Game.objects.create(title="Space Pong", game_link="https://example.com/pong")
        response = self.client.get(reverse("minigames:list"), {"q": "maze"})
        self.assertContains(response, "Maze Runner")
        self.assertNotContains(response, "Space Pong")

    def test_slug_is_created_and_unique(self):
        first = Game.objects.create(title="Same Name", game_link="https://example.com/1")
        second = Game.objects.create(title="Same Name", game_link="https://example.com/2")
        self.assertEqual(first.slug, "same-name")
        self.assertEqual(second.slug, "same-name-2")

    def test_link_validator(self):
        validate_game_link("https://example.com/play")
        validate_game_link("/static/games/maze.html")
        for bad in ("javascript:alert(1)", "example.com", "//evil.com", "https://", "ftp://x.com"):
            with self.subTest(link=bad):
                with self.assertRaises(ValidationError):
                    validate_game_link(bad)

    def test_menu_links_to_mini_game_page(self):
        response = self.client.get("/")
        self.assertContains(response, reverse("minigames:list"))
