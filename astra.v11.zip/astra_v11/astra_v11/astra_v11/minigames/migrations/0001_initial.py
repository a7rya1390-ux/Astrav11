import core.validators
import minigames.models
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Game",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(help_text="The game name, for example: Backrooms.", max_length=120)),
                ("slug", models.SlugField(blank=True, max_length=140, unique=True)),
                ("description", models.TextField(blank=True, help_text="A short description shown on the game card.")),
                (
                    "image",
                    models.ImageField(
                        blank=True,
                        help_text="Cover image shown on the game card.",
                        null=True,
                        upload_to="minigames/",
                        validators=[core.validators.validate_image_file],
                    ),
                ),
                ("button_text", models.CharField(default="Play", help_text="The text on the card button.", max_length=30)),
                (
                    "game_link",
                    models.CharField(
                        help_text="Where the Play button goes. Paste the full link to your game.",
                        max_length=300,
                        validators=[minigames.models.validate_game_link],
                    ),
                ),
                ("order", models.PositiveIntegerField(default=0, help_text="Lower numbers appear first.")),
                ("is_published", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={
                "verbose_name": "Game",
                "verbose_name_plural": "Games",
                "ordering": ["order", "-created_at"],
            },
        ),
    ]
