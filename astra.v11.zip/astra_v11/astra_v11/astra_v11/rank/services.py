from datetime import date, datetime, time, timedelta
from django.db import transaction
from django.db.models import Sum
from django.contrib.auth import get_user_model
from django.utils import timezone
from .models import RankPeriodPrize, Submission


def _period_start(day, period):
    if period == "quarterly": return date(day.year, ((day.month - 1) // 3) * 3 + 1, 1)
    return date(day.year, 1, 1)


def _period_end(start, period):
    if period == "quarterly":
        return date(start.year + (start.month == 10), 1 if start.month == 10 else start.month + 3, 1)
    return date(start.year + 1, 1, 1)


def _aware(day):
    return timezone.make_aware(datetime.combine(day, time.min), timezone.get_current_timezone())


@transaction.atomic
def finalize_closed_rank_prizes(today=None):
    """Persist only quarterly and annual Rank winners; prize claims never change points."""
    today = today or timezone.localdate()
    scored_dates = Submission.objects.filter(status=Submission.Status.APPROVED).dates("created_at", "month", order="ASC")
    created = 0
    for period in ("quarterly", "yearly"):
        starts = sorted({_period_start(day, period) for day in scored_dates})
        for start in starts:
            end = _period_end(start, period)
            if end > today or RankPeriodPrize.objects.filter(period_type=period, period_start=start).exists():
                continue
            winner = (Submission.objects.filter(status=Submission.Status.APPROVED, created_at__gte=_aware(start), created_at__lt=_aware(end))
                      .values("user_id").annotate(total=Sum("points")).filter(total__gt=0)
                      .order_by("-total", "user__username").first())
            if not winner:
                continue
            label = "Quarterly" if period == "quarterly" else "Annual"
            RankPeriodPrize.objects.get_or_create(
                period_type=period, period_start=start,
                defaults={"period_end": end - timedelta(days=1), "user_id": winner["user_id"],
                          "title": f"Astra Rank {label} Champion", "icon": "🏆", "score_at_close": winner["total"]},
            )
            created += 1
    return created


def sync_top_rank_record(now=None):
    """Close/open the continuous first-place streak immediately after admin score changes."""
    now = now or timezone.now()
    User = get_user_model()
    top_user = (User.objects.filter(rank_submissions__status=Submission.Status.APPROVED)
                .annotate(total_points=Sum("rank_submissions__points")).filter(total_points__gt=0)
                .order_by("-total_points", "username").first())
    from .models import TopRankRecord
    record = TopRankRecord.objects.filter(ended_at__isnull=True).order_by("-since").first()
    if top_user is None:
        if record:
            record.ended_at = now
            record.save(update_fields=["ended_at"])
        return None
    if record is None or record.user_id != top_user.pk:
        if record:
            record.ended_at = now
            record.save(update_fields=["ended_at"])
        record = TopRankRecord.objects.create(user=top_user, since=now)
    return record
