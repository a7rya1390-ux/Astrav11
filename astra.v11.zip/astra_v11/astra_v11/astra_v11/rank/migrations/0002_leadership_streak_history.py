from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("rank", "0001_initial")]
    operations = [
        migrations.AddField(model_name="toprankrecord", name="ended_at", field=models.DateTimeField(blank=True, db_index=True, null=True)),
        migrations.AddIndex(model_name="toprankrecord", index=models.Index(fields=["user", "since"], name="rank_toprank_user_id_5b7301_idx")),
        migrations.AlterModelOptions(name="toprankrecord", options={"ordering": ["-since"]}),
    ]
