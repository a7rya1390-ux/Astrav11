from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("rank", "0003_rank_period_prizes")]
    operations = [
        migrations.AlterField(
            model_name="submission",
            name="category",
            field=models.CharField(
                choices=[
                    ("certificate", "Certificate photo (10 pts)"),
                    ("medal", "Medal photo (50 pts)"),
                    ("stat_screenshot", "Stats/graph screenshot, e.g. LinkedIn analytics (5 pts)"),
                    ("course_completion", "Course completion proof (15 pts)"),
                    ("competition_award", "Competition award/trophy photo (30 pts)"),
                    ("community_contribution", "Community contribution proof, e.g. open-source PR merged (20 pts)"),
                ],
                max_length=64,
            ),
        ),
    ]
