from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
import core.validators


class Migration(migrations.Migration):
    dependencies = [
        ("rank", "0002_leadership_streak_history"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel(
            name="RankPeriodPrize",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("period_type", models.CharField(choices=[("quarterly", "Quarterly"), ("yearly", "Yearly")], db_index=True, max_length=12)),
                ("period_start", models.DateField(db_index=True)),
                ("period_end", models.DateField()),
                ("title", models.CharField(max_length=120)),
                ("icon", models.CharField(default="🏆", max_length=12)),
                ("image", models.ImageField(blank=True, null=True, upload_to="rank/trophies/", validators=[core.validators.validate_image_file])),
                ("score_at_close", models.PositiveIntegerField(default=0)),
                ("awarded_at", models.DateTimeField(default=django.utils.timezone.now)),
                ("claimed_at", models.DateTimeField(blank=True, null=True)),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="astra_rank_period_prizes", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-period_end", "period_type"]},
        ),
        migrations.AddConstraint(model_name="rankperiodprize", constraint=models.UniqueConstraint(fields=("period_type", "period_start"), name="unique_rank_period_prize")),
        migrations.AddIndex(model_name="rankperiodprize", index=models.Index(fields=["user", "claimed_at"], name="rank_prize_user_claimed_idx")),
    ]
