from datetime import date, datetime, timedelta
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone
from .models import RankPeriodPrize, Submission, TopRankRecord
from .services import finalize_closed_rank_prizes, sync_top_rank_record

User = get_user_model()


class RankPrizeTests(TestCase):
    def test_closed_quarter_prize_goes_to_top_rank_user_and_does_not_create_awards_score(self):
        from awards.models import ScoreEntry
        winner = User.objects.create_user(username="rank_winner", password="Safe-Test-Password-2026!")
        loser = User.objects.create_user(username="rank_loser", password="Safe-Test-Password-2026!")
        first = Submission.objects.create(user=winner, category=Submission.Category.MEDAL, proof_image="medal.png", status=Submission.Status.APPROVED)
        second = Submission.objects.create(user=loser, category=Submission.Category.CERTIFICATE, proof_image="certificate.png", status=Submission.Status.APPROVED)
        start = timezone.make_aware(datetime(2026, 1, 15, 12, 0))
        Submission.objects.filter(pk=first.pk).update(created_at=start)
        Submission.objects.filter(pk=second.pk).update(created_at=start)
        created = finalize_closed_rank_prizes(today=date(2026, 11, 12))
        self.assertGreaterEqual(created, 1)
        prize = RankPeriodPrize.objects.get(period_type="quarterly", period_start=date(2026, 1, 1))
        self.assertEqual(prize.user_id, winner.pk)
        self.assertEqual(prize.score_at_close, 50)
        self.assertFalse(ScoreEntry.objects.filter(user=winner, kind=ScoreEntry.Kind.RANK).exists())

    def test_claim_is_limited_to_the_winner_and_is_idempotent(self):
        winner = User.objects.create_user(username="prize_owner", password="Safe-Test-Password-2026!")
        other = User.objects.create_user(username="not_the_winner", password="Safe-Test-Password-2026!")
        prize = RankPeriodPrize.objects.create(period_type="yearly", period_start=date(2025, 1, 1), period_end=date(2025, 12, 31), user=winner, title="Astra Rank Annual Champion")
        self.client.force_login(other)
        self.assertEqual(self.client.post(f"/rank/prize/claim/{prize.pk}/").status_code, 404)
        prize.refresh_from_db()
        self.assertIsNone(prize.claimed_at)
        self.client.force_login(winner)
        self.assertEqual(self.client.post(f"/rank/prize/claim/{prize.pk}/").status_code, 302)
        prize.refresh_from_db()
        first_claim = prize.claimed_at
        self.client.post(f"/rank/prize/claim/{prize.pk}/")
        prize.refresh_from_db()
        self.assertEqual(prize.claimed_at, first_claim)

    def test_returning_to_first_place_starts_a_new_streak(self):
        leader = User.objects.create_user(username="leader_one", password="Safe-Test-Password-2026!")
        challenger = User.objects.create_user(username="leader_two", password="Safe-Test-Password-2026!")
        Submission.objects.create(user=leader, category=Submission.Category.MEDAL, proof_image="leader-before.png", status=Submission.Status.APPROVED)
        old_streak = TopRankRecord.objects.create(user=leader, since=timezone.now()-timedelta(days=50))
        sync_top_rank_record()
        # The second member takes first place after earning two medals.
        Submission.objects.create(user=challenger, category=Submission.Category.MEDAL, proof_image="a.png", status=Submission.Status.APPROVED)
        Submission.objects.create(user=challenger, category=Submission.Category.MEDAL, proof_image="b.png", status=Submission.Status.APPROVED)
        second_streak = sync_top_rank_record()
        old_streak.refresh_from_db()
        self.assertIsNotNone(old_streak.ended_at)
        self.assertEqual(second_streak.user_id, challenger.pk)
        # The original leader regains first place; their old streak must stay closed.
        Submission.objects.create(user=leader, category=Submission.Category.MEDAL, proof_image="c.png", status=Submission.Status.APPROVED)
        Submission.objects.create(user=leader, category=Submission.Category.MEDAL, proof_image="d.png", status=Submission.Status.APPROVED)
        final_streak = sync_top_rank_record()
        second_streak.refresh_from_db()
        self.assertIsNotNone(second_streak.ended_at)
        self.assertEqual(final_streak.user_id, leader.pk)
        self.assertGreater(final_streak.since, old_streak.since)

class RankAwardsSyncTests(TestCase):
    def test_approved_rank_points_feed_awards_once_and_update_after_category_edit(self):
        from awards.models import ScoreEntry
        from awards.services import record_rank_submission_score

        member = User.objects.create_user(username="rank_awards_member", password="Safe-Test-Password-2026!")
        submission = Submission.objects.create(
            user=member,
            category=Submission.Category.MEDAL,
            proof_image="rank-proof.png",
            status=Submission.Status.APPROVED,
        )
        record_rank_submission_score(submission)
        record_rank_submission_score(submission)
        self.assertEqual(ScoreEntry.objects.filter(source_key=f"rank:{submission.pk}").count(), 1)
        self.assertEqual(ScoreEntry.objects.get(source_key=f"rank:{submission.pk}").points, 50)

        submission.category = Submission.Category.CERTIFICATE
        submission.save()
        record_rank_submission_score(submission)
        entry = ScoreEntry.objects.get(source_key=f"rank:{submission.pk}")
        self.assertEqual(entry.points, 10)
        self.assertEqual(ScoreEntry.objects.filter(user=member, kind=ScoreEntry.Kind.RANK).count(), 1)

class RankFieldCompatibilityTests(TestCase):
    def test_category_field_supports_longer_internal_names(self):
        self.assertEqual(Submission._meta.get_field("category").max_length, 64)
