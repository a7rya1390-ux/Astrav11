from django.urls import path

from . import views

app_name = "rank"

urlpatterns = [
    path("", views.leaderboard, name="leaderboard"),
    path("submit/", views.submit_guide, name="submit"),
    path("prize/claim/<int:prize_id>/", views.claim_rank_prize, name="claim_prize"),
]
