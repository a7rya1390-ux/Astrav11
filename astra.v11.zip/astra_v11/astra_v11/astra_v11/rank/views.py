from datetime import date, datetime, time, timedelta
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST
from .models import RankPeriodPrize, Submission, TopRankRecord
from .services import finalize_closed_rank_prizes, sync_top_rank_record

User = get_user_model()
MEDALS = {1: "🥇", 2: "🥈", 3: "🥉", 4: "🏅", 5: "🏅", 6: "🎖️"}
LABELS = {4: "4th", 5: "5th", 6: "6th"}
PERIODS = {"all": "All time", "daily": "Today", "weekly": "This week", "monthly": "This month", "quarterly": "This quarter", "yearly": "This year"}


def _humanize_duration(delta):
    days = max(delta.days, 0)
    if days >= 1: return f"{days} day{'s' if days != 1 else ''}"
    hours = delta.seconds // 3600
    if hours >= 1: return f"{hours} hour{'s' if hours != 1 else ''}"
    return "less than an hour"


def _period_start(day, period):
    if period == "daily": return day
    if period == "weekly": return day - timedelta(days=day.weekday())
    if period == "monthly": return day.replace(day=1)
    if period == "quarterly": return date(day.year, ((day.month - 1)//3)*3 + 1, 1)
    if period == "yearly": return date(day.year, 1, 1)
    return None


def _period_bounds(day, period):
    start_date = _period_start(day, period)
    if period == "daily": end_date = start_date + timedelta(days=1)
    elif period == "weekly": end_date = start_date + timedelta(days=7)
    elif period == "monthly": end_date = date(start_date.year + (start_date.month == 12), 1 if start_date.month == 12 else start_date.month + 1, 1)
    elif period == "quarterly": end_date = date(start_date.year + (start_date.month == 10), 1 if start_date.month == 10 else start_date.month + 3, 1)
    else: end_date = date(start_date.year + 1, 1, 1)
    tz = timezone.get_current_timezone()
    return timezone.make_aware(datetime.combine(start_date, time.min), tz), timezone.make_aware(datetime.combine(end_date, time.min), tz)


@login_required
def leaderboard(request):
    today = timezone.localdate()
    finalize_closed_rank_prizes(today=today)
    period = request.GET.get("period", "all")
    if period not in PERIODS: period = "all"
    submissions = Submission.objects.filter(status=Submission.Status.APPROVED)
    if period != "all":
        start, end = _period_bounds(today, period)
        submissions = submissions.filter(created_at__gte=start, created_at__lt=end)
    ranked_users = list(User.objects.filter(rank_submissions__in=submissions)
        .annotate(total_points=Sum("rank_submissions__points"))
        .filter(total_points__gt=0).select_related("profile").order_by("-total_points", "username")[:20])
    rows = [{"position": i, "user": u, "points": u.total_points, "medal": MEDALS.get(i, ""), "label": LABELS.get(i, f"{i}th")} for i, u in enumerate(ranked_users, 1)]

    # The tenure clock follows the all-time leader, not the selected view filter.
    all_time = list(User.objects.filter(rank_submissions__status=Submission.Status.APPROVED)
        .annotate(total_points=Sum("rank_submissions__points")).filter(total_points__gt=0)
        .select_related("profile").order_by("-total_points", "username")[:1])
    top_user = all_time[0] if all_time else None
    sync_top_rank_record()
    current_record = TopRankRecord.objects.filter(ended_at__isnull=True).order_by("-since").first()
    now = timezone.now()
    held_since_text = _humanize_duration(now - current_record.since) if current_record and current_record.user_id else None
    history = TopRankRecord.objects.select_related("user").order_by("-since")[:15]

    return render(request, "rank/leaderboard.html", {
        "rows": rows, "top_user": top_user, "held_since_text": held_since_text,
        "period": period, "periods": PERIODS, "history": history,
        "claimable_prizes": RankPeriodPrize.objects.filter(user=request.user, claimed_at__isnull=True),
        "claimed_prizes": RankPeriodPrize.objects.filter(user=request.user, claimed_at__isnull=False),
        "show_prize_celebration": bool(request.session.pop("astra_claimed_rank_prize_id", None)),
    })


@login_required
def submit_guide(request):
    if request.method == "POST":
        category = request.POST.get("category")
        proof = request.FILES.get("proof_image")
        note = request.POST.get("note", "").strip()[:200]
        valid_categories = dict(Submission.Category.choices)
        if category not in valid_categories: messages.error(request, "Please choose a valid category.")
        elif not proof: messages.error(request, "Please attach a proof image.")
        else:
            submission = Submission(user=request.user, category=category, proof_image=proof, note=note)
            try:
                submission.full_clean()
            except ValidationError as exc:
                for error in exc.messages:
                    messages.error(request, error)
            else:
                submission.save()
                messages.success(request, "Submitted! Your points will appear once it's reviewed.")
                return redirect("rank:leaderboard")
    my_submissions = Submission.objects.filter(user=request.user)
    return render(request, "rank/submit.html", {"categories": Submission.Category.choices, "points_map": Submission.POINTS_BY_CATEGORY, "my_submissions": my_submissions})


@login_required
@require_POST
@transaction.atomic
def claim_rank_prize(request, prize_id):
    prize = get_object_or_404(RankPeriodPrize.objects.select_for_update(), pk=prize_id, user=request.user)
    if prize.claimed_at is None:
        prize.claimed_at = timezone.now()
        prize.save(update_fields=["claimed_at"])
        request.session["astra_claimed_rank_prize_id"] = prize.pk
        messages.success(request, "Your Astra Rank prize has been revealed and saved to your profile.")
    else:
        messages.info(request, "This Astra Rank prize is already in your collection.")
    return redirect("rank:leaderboard")
