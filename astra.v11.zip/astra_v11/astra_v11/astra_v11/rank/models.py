from django.conf import settings
from django.db import models
from django.utils import timezone

from core.validators import validate_image_file


class Submission(models.Model):
    """
    A single proof-of-achievement submitted by a user for Astra Rank
    points. Points are assigned automatically based on category, but the
    submission stays "Pending" until an admin reviews the proof image
    and approves it — only approved submissions count toward the
    leaderboard. Fully automatic image verification (telling a real
    certificate apart from a fake one) isn't something that can be done
    reliably, so a quick manual approval step keeps the leaderboard
    trustworthy.
    """

    class Category(models.TextChoices):
        CERTIFICATE = "certificate", "Certificate photo (10 pts)"
        MEDAL = "medal", "Medal photo (50 pts)"
        STAT_SCREENSHOT = "stat_screenshot", "Stats/graph screenshot, e.g. LinkedIn analytics (5 pts)"
        COURSE_COMPLETION = "course_completion", "Course completion proof (15 pts)"
        COMPETITION_AWARD = "competition_award", "Competition award/trophy photo (30 pts)"
        COMMUNITY_CONTRIBUTION = "community_contribution", "Community contribution proof, e.g. open-source PR merged (20 pts)"

    POINTS_BY_CATEGORY = {
        Category.CERTIFICATE: 10,
        Category.MEDAL: 50,
        Category.STAT_SCREENSHOT: 5,
        Category.COURSE_COMPLETION: 15,
        Category.COMPETITION_AWARD: 30,
        Category.COMMUNITY_CONTRIBUTION: 20,
    }

    class Status(models.TextChoices):
        PENDING = "pending", "Pending review"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="rank_submissions")
    category = models.CharField(max_length=64, choices=Category.choices)
    proof_image = models.ImageField(upload_to="rank_submissions/", validators=[validate_image_file])
    points = models.PositiveIntegerField(editable=False, default=0)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    note = models.CharField(max_length=200, blank=True, help_text="Optional note from the user about this submission.")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def save(self, *args, **kwargs):
        category_changed = not self.pk
        if self.pk:
            old_category = type(self).objects.filter(pk=self.pk).values_list("category", flat=True).first()
            category_changed = old_category != self.category
        if category_changed:
            self.points = self.POINTS_BY_CATEGORY.get(self.category, 0)
            update_fields = kwargs.get("update_fields")
            if update_fields is not None:
                kwargs["update_fields"] = set(update_fields) | {"points"}
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user} — {self.get_category_display()} ({self.get_status_display()})"


class TopRankRecord(models.Model):
    """
    Tracks who currently holds 1st place and since when, so the
    leaderboard can show "X has been #1 for N days" without recomputing
    history from scratch on every page load.
    """

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True)
    since = models.DateTimeField(default=timezone.now)
    ended_at = models.DateTimeField(null=True, blank=True, db_index=True)

    class Meta:
        ordering = ["-since"]
        indexes = [models.Index(fields=["user", "since"], name="rank_toprank_user_id_idx")]

    @property
    def is_current(self):
        return self.ended_at is None

    def __str__(self):
        return f"#1: {self.user} since {self.since:%Y-%m-%d}"


class RankPeriodPrize(models.Model):
    """A distinct trophy for the first-place Astra Rank holder in a closed quarter or year."""
    class Period(models.TextChoices):
        QUARTERLY = "quarterly", "Quarterly"
        YEARLY = "yearly", "Yearly"

    period_type = models.CharField(max_length=12, choices=Period.choices, db_index=True)
    period_start = models.DateField(db_index=True)
    period_end = models.DateField()
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="astra_rank_period_prizes")
    title = models.CharField(max_length=120)
    icon = models.CharField(max_length=12, default="🏆")
    image = models.ImageField(upload_to="rank/trophies/", blank=True, null=True, validators=[validate_image_file])
    score_at_close = models.PositiveIntegerField(default=0)
    awarded_at = models.DateTimeField(default=timezone.now)
    claimed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-period_end", "period_type"]
        constraints = [models.UniqueConstraint(fields=["period_type", "period_start"], name="unique_rank_period_prize")]
        indexes = [models.Index(fields=["user", "claimed_at"], name="rank_prize_user_claimed_idx")]

    def __str__(self):
        return f"{self.user} — {self.title} ({self.period_start})"
