from django.contrib import admin
from django.db.models import Count
from django.utils.html import format_html

from .models import MusicCategory, Song


@admin.register(MusicCategory)
class MusicCategoryAdmin(admin.ModelAdmin):
    list_display = ("full_path", "parent", "icon", "song_total", "order", "is_published")
    list_editable = ("order", "is_published")
    list_filter = ("is_published",)
    search_fields = ("name", "full_path")
    ordering = ("full_path",)
    fieldsets = (
        (
            "Category",
            {
                "description": (
                    "Build your own music tree. Create a top-level category such as <strong>Persian</strong> "
                    "or <strong>English</strong>, then add deeper levels by choosing a parent, for example "
                    "<em>Persian › Sad › Traditional</em> or <em>English › Rock</em>."
                ),
                "fields": ("name", "parent", "icon"),
            },
        ),
        ("Display", {"fields": ("order", "is_published")}),
    )

    def get_queryset(self, request):
        return super().get_queryset(request).select_related("parent").annotate(_song_total=Count("songs"))

    @admin.display(description="Songs", ordering="_song_total")
    def song_total(self, obj):
        return obj._song_total


@admin.register(Song)
class SongAdmin(admin.ModelAdmin):
    list_display = ("cover_thumbnail", "title", "artist", "category", "order", "is_published", "created_at")
    list_display_links = ("cover_thumbnail", "title")
    list_editable = ("order", "is_published")
    list_filter = ("is_published", "category")
    search_fields = ("title", "artist", "category__full_path")
    readonly_fields = ("created_at", "cover_preview")
    fieldsets = (
        ("Song", {"fields": ("title", "artist", "cover_image", "cover_preview", "audio_file")}),
        (
            "Category",
            {
                "description": (
                    "Pick the language first, then the mood and style. Need a new category? "
                    "Use the green + button next to the list, or add it under <em>Music categories</em>."
                ),
                "fields": ("category",),
            },
        ),
        ("Visibility", {"fields": ("order", "is_published", "created_at")}),
    )

    @admin.display(description="Cover")
    def cover_thumbnail(self, obj):
        if not obj.cover_image:
            return "—"
        return format_html('<img src="{}" alt="" style="width:54px;height:54px;object-fit:cover;border-radius:8px" />', obj.cover_image.url)

    @admin.display(description="Uploaded cover preview")
    def cover_preview(self, obj):
        if not obj or not obj.cover_image:
            return "No cover image uploaded"
        return format_html('<a href="{}" target="_blank" rel="noopener"><img src="{}" style="max-width:360px;max-height:260px;object-fit:contain;border-radius:9px" /></a>', obj.cover_image.url, obj.cover_image.url)

    class Media:
        css = {"all": ("css/astra-admin-music.css",)}
        js = ("js/astra-admin-music.js",)

    def get_queryset(self, request):
        return super().get_queryset(request).select_related("category")
