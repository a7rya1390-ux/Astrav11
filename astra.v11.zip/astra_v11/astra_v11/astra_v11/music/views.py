from django.db.models import Q
from django.shortcuts import render

from .models import MusicCategory, Song

UNCATEGORIZED_LABEL = "More songs"


def _group_songs(songs, published_ids):
    """Group songs by category so songs from the same category sit side by side."""
    buckets = {}
    for song in songs:
        category = song.category if song.category_id in published_ids else None
        key = category.pk if category else None
        buckets.setdefault(key, {"category": category, "songs": []})["songs"].append(song)

    def sort_key(bucket):
        category = bucket["category"]
        return (1, "") if category is None else (0, category.full_path.lower())

    return sorted(buckets.values(), key=sort_key)


def music_list(request):
    query = request.GET.get("q", "").strip()
    category_slug = request.GET.get("cat", "").strip()

    published_categories = list(MusicCategory.objects.filter(is_published=True))
    published_ids = {category.pk for category in published_categories}

    current = None
    if category_slug:
        current = next((c for c in published_categories if c.slug == category_slug), None)

    songs = Song.objects.filter(is_published=True).select_related("category")
    if current is not None:
        songs = songs.filter(category_id__in=current.descendant_ids())
    if query:
        songs = songs.filter(
            Q(title__icontains=query) | Q(artist__icontains=query) | Q(category__full_path__icontains=query)
        )
    songs = list(songs)

    child_parent_id = current.pk if current is not None else None
    chips = sorted(
        (c for c in published_categories if c.parent_id == child_parent_id),
        key=lambda c: (c.order, c.name.lower()),
    )
    breadcrumbs = [node for node in current.ancestors() if node.pk in published_ids] if current else []

    context = {
        "songs": songs,
        "groups": _group_songs(songs, published_ids),
        "query": query,
        "current": current,
        "chips": chips,
        "breadcrumbs": breadcrumbs,
        "has_categories": bool(published_categories),
        "uncategorized_label": UNCATEGORIZED_LABEL,
    }
    return render(request, "music/music_list.html", context)
