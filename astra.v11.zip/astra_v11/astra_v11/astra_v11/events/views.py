from datetime import timedelta
from django.shortcuts import render
from django.utils import timezone
from .models import Event


def event_list(request):
    now = timezone.now()
    published = Event.objects.filter(is_published=True).prefetch_related("effects").order_by("starts_at", "title")
    live_events = [event for event in published if event.starts_at <= now <= event.ends_at]
    upcoming_events = [event for event in published if event.starts_at > now]
    past_events = [event for event in published if event.ends_at < now]
    nearby_events = [event for event in live_events] + [event for event in upcoming_events if event.starts_at <= now + timedelta(days=7)]
    selected_event = None
    requested_slug = request.GET.get("event", "").strip()
    if requested_slug:
        selected_event = next((event for event in nearby_events if event.slug == requested_slug), None)
    if selected_event is None:
        selected_event = (live_events or nearby_events or [None])[0]
    return render(request, "events/event_list.html", {
        "live_events": live_events, "upcoming_events": upcoming_events, "past_events": past_events,
        "nearby_events": nearby_events, "selected_event": selected_event,
    })
