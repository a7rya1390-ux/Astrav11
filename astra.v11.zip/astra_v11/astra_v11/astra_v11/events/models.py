from django.core.validators import RegexValidator
from django.db import models
from django.utils import timezone
from django.utils.text import slugify

hex_color_validator = RegexValidator(regex=r"^#[0-9A-Fa-f]{6}$", message="Enter a valid six-character HEX color, for example #F5C16C.")


class CelebrationEffect(models.Model):
    EFFECT_TYPES = [
        ("snowfall", "Snowfall"), ("santa", "Santa fly-by"), ("fireworks", "Firework-style light bursts"),
        ("sparks", "Golden sparks"), ("confetti", "Colorful confetti"), ("garlands", "Festive garlands"),
        ("stars", "Floating stars"), ("lanterns", "Lantern glow"),
    ]
    name = models.CharField(max_length=80)
    key = models.SlugField(max_length=24, unique=True, choices=EFFECT_TYPES)
    description = models.CharField(max_length=180, blank=True)
    is_enabled = models.BooleanField(default=True)
    order = models.PositiveSmallIntegerField(default=0)
    class Meta:
        ordering = ["order", "name"]
        verbose_name = "Celebration effect"
        verbose_name_plural = "Celebration effect library"
    def __str__(self): return self.name


class Event(models.Model):
    class Theme(models.TextChoices):
        GOLD = "gold", "Astra Gold"
        WINTER = "winter", "Winter Lights"
        SPRING = "spring", "Spring Festival"
        MIDNIGHT = "midnight", "Midnight Celebration"
        CUSTOM = "custom", "Custom Celebration"

    title = models.CharField(max_length=120)
    slug = models.SlugField(max_length=140, unique=True, blank=True)
    description = models.TextField(blank=True)
    celebration_message = models.CharField(max_length=180, default="The celebration starts here!", help_text="The large message shown when visitors open this event.")
    starts_at = models.DateTimeField(help_text="The event becomes live at this date and time.")
    ends_at = models.DateTimeField(help_text="The event stops being live at this date and time.")
    theme = models.CharField(max_length=16, choices=Theme.choices, default=Theme.GOLD)
    accent_color = models.CharField(max_length=7, default="#F5C16C", validators=[hex_color_validator], help_text="Six-digit HEX color, such as #F5C16C.")
    icon = models.CharField(max_length=12, default="✨", help_text="A short celebration emoji.")
    effects = models.ManyToManyField(CelebrationEffect, blank=True, related_name="events", help_text="Choose up to three visual effects from the effect library.")
    is_published = models.BooleanField(default=False)
    confetti_enabled = models.BooleanField(default=True, help_text="Keep the legacy Celebrate Together confetti button available.")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["starts_at", "title"]
        verbose_name = "Event"
        verbose_name_plural = "Events"

    def __str__(self): return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title) or "astra-event"
            candidate, suffix = base_slug, 2
            while Event.objects.filter(slug=candidate).exclude(pk=self.pk).exists():
                candidate = f"{base_slug}-{suffix}"; suffix += 1
            self.slug = candidate
        super().save(*args, **kwargs)

    @property
    def is_live(self):
        now = timezone.now()
        return self.is_published and self.starts_at <= now <= self.ends_at

    @property
    def is_upcoming(self): return self.is_published and timezone.now() < self.starts_at
    @property
    def is_finished(self): return timezone.now() > self.ends_at
    @property
    def status_label(self):
        if not self.is_published: return "Draft"
        if self.is_live: return "Live now"
        if self.is_upcoming: return "Coming soon"
        return "Finished"

    def clean(self):
        super().clean()
        from django.core.exceptions import ValidationError
        errors = {}
        if self.starts_at and self.ends_at and self.ends_at <= self.starts_at:
            errors["ends_at"] = "The end date must be after the start date."
        if self.pk and self.effects.count() > 3:
            errors["effects"] = "Choose no more than three visual effects for one celebration."
        if errors: raise ValidationError(errors)
