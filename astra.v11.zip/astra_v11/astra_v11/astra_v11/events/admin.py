from django import forms
from django.contrib import admin
from django.core.exceptions import ValidationError
from .models import CelebrationEffect, Event


class EventAdminForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = "__all__"
    def clean_effects(self):
        effects = self.cleaned_data.get("effects")
        if effects and effects.count() > 3:
            raise ValidationError("Choose no more than three visual effects for one celebration.")
        return effects


@admin.register(CelebrationEffect)
class CelebrationEffectAdmin(admin.ModelAdmin):
    list_display = ("name", "key", "is_enabled", "order")
    list_editable = ("is_enabled", "order")
    list_filter = ("is_enabled",)
    search_fields = ("name", "description", "key")


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    form = EventAdminForm
    list_display = ("title", "starts_at", "ends_at", "theme", "is_published", "status")
    list_filter = ("is_published", "theme", "starts_at")
    search_fields = ("title", "description", "celebration_message")
    prepopulated_fields = {"slug": ("title",)}
    filter_horizontal = ("effects",)
    date_hierarchy = "starts_at"
    ordering = ("-starts_at",)
    fieldsets = (
        ("Event details", {"fields": ("title", "slug", "description", "celebration_message", "icon")}),
        ("Schedule", {"fields": ("starts_at", "ends_at", "is_published")}),
        ("Celebration design", {"fields": ("theme", "accent_color", "effects", "confetti_enabled")}),
        ("Timestamps", {"fields": ("created_at", "updated_at"), "classes": ("collapse",)}),
    )
    readonly_fields = ("created_at", "updated_at")
    def formfield_for_manytomany(self, db_field, request, **kwargs):
        if db_field.name == "effects": kwargs["queryset"] = CelebrationEffect.objects.filter(is_enabled=True)
        return super().formfield_for_manytomany(db_field, request, **kwargs)
    @admin.display(description="Status")
    def status(self, obj): return obj.status_label
