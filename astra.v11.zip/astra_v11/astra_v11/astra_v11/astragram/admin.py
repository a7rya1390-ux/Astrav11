from django.contrib import admin
from django.utils.html import format_html

from accour.models import Profile
from .models import Comment, Like, Message, Post


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ("author", "image_thumbnail", "created_at", "like_count", "comment_count", "is_visible", "is_pinned", "author_is_verified")
    list_editable = ("is_visible", "is_pinned")
    list_filter = ("is_visible", "is_pinned", "created_at")
    search_fields = ("author__username", "author__email", "caption")
    readonly_fields = ("created_at", "like_count", "comment_count", "image_preview")
    fields = ("author", "caption", "image", "image_preview", "created_at", "like_count", "comment_count", "is_visible", "is_pinned")
    date_hierarchy = "created_at"
    list_select_related = ("author", "author__profile")
    actions = ["show_posts", "hide_posts", "pin_posts", "unpin_posts", "verify_authors", "unverify_authors"]
    list_per_page = 40

    @admin.display(description="Image")
    def image_thumbnail(self, obj):
        if not obj.image:
            return "—"
        return format_html('<img src="{}" style="width:52px;height:52px;object-fit:cover;border-radius:7px" />', obj.image.url)

    @admin.display(description="Uploaded post image")
    def image_preview(self, obj):
        if not obj or not obj.image:
            return "No image uploaded"
        return format_html('<a href="{}" target="_blank" rel="noopener"><img src="{}" style="max-width:360px;max-height:280px;object-fit:contain;border-radius:9px" /></a>', obj.image.url, obj.image.url)

    @admin.display(boolean=True, description="Author verified")
    def author_is_verified(self, obj):
        return getattr(getattr(obj.author, "profile", None), "is_verified", False)

    @admin.action(description="Show selected posts on the public feed")
    def show_posts(self, request, queryset): queryset.update(is_visible=True)

    @admin.action(description="Hide selected posts without deleting them")
    def hide_posts(self, request, queryset): queryset.update(is_visible=False)

    @admin.action(description="Pin selected posts")
    def pin_posts(self, request, queryset): queryset.update(is_pinned=True)

    @admin.action(description="Unpin selected posts")
    def unpin_posts(self, request, queryset): queryset.update(is_pinned=False)

    @admin.action(description="Give a blue checkmark to the author(s) of selected posts")
    def verify_authors(self, request, queryset):
        for post in queryset.select_related("author"):
            profile, _ = Profile.objects.get_or_create(user=post.author)
            profile.is_verified = True
            profile.save(update_fields=["is_verified"])

    @admin.action(description="Remove the blue checkmark from selected post author(s)")
    def unverify_authors(self, request, queryset):
        for post in queryset.select_related("author"):
            profile, _ = Profile.objects.get_or_create(user=post.author)
            profile.is_verified = False
            profile.save(update_fields=["is_verified"])


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ("post", "user", "short_text", "is_visible", "created_at")
    list_editable = ("is_visible",)
    list_filter = ("is_visible", "created_at")
    search_fields = ("user__username", "post__caption", "text")
    list_select_related = ("post", "user")
    readonly_fields = ("created_at",)
    date_hierarchy = "created_at"
    actions = ["show_comments", "hide_comments"]

    @admin.display(description="Comment")
    def short_text(self, obj): return obj.text[:80]

    @admin.action(description="Show selected comments")
    def show_comments(self, request, queryset): queryset.update(is_visible=True)

    @admin.action(description="Hide selected comments without deleting them")
    def hide_comments(self, request, queryset): queryset.update(is_visible=False)


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ("sender", "recipient", "short_text", "is_read", "created_at")
    list_filter = ("is_read", "created_at")
    search_fields = ("sender__username", "recipient__username", "text")
    readonly_fields = ("sender", "recipient", "text", "created_at", "read_at", "is_read")
    list_select_related = ("sender", "recipient")
    date_hierarchy = "created_at"
    list_per_page = 50

    @admin.display(description="Message")
    def short_text(self, obj): return obj.text[:90]

    def has_add_permission(self, request): return False


@admin.register(Like)
class LikeAdmin(admin.ModelAdmin):
    list_display = ("post", "user", "created_at")
    list_filter = ("created_at",)
    search_fields = ("post__caption", "user__username")
    readonly_fields = ("post", "user", "created_at")
    date_hierarchy = "created_at"

    def has_add_permission(self, request): return False
