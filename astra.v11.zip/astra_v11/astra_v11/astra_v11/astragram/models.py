from django.conf import settings
from django.db import models
from django.utils import timezone
from core.validators import validate_image_file


class Post(models.Model):
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="astragram_posts")
    image = models.ImageField(upload_to="astragram/posts/", blank=True, null=True, validators=[validate_image_file])
    caption = models.TextField(blank=True)
    is_visible = models.BooleanField(default=True, db_index=True, help_text="Uncheck to hide this post from the public Astragram feed without deleting it.")
    is_pinned = models.BooleanField(default=False, db_index=True, help_text="Pinned posts appear first in the public feed.")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-is_pinned", "-created_at"]
        indexes = [models.Index(fields=["is_visible", "-is_pinned", "-created_at"], name="astragram_p_visibl_7fda25_idx")]

    def __str__(self):
        return f"Post by {self.author} at {self.created_at:%Y-%m-%d %H:%M}"

    @property
    def like_count(self):
        return self.likes.count()

    @property
    def comment_count(self):
        return getattr(self, "visible_comment_count", None) if hasattr(self, "visible_comment_count") else self.comments.filter(is_visible=True).count()


class Like(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="likes")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="astragram_likes")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["post", "user"], name="unique_astragram_like_per_user")]
        indexes = [models.Index(fields=["post", "created_at"], name="astragram_l_post_id_4e6d2a_idx")]


class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="comments")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="astragram_comments")
    text = models.CharField(max_length=500)
    is_visible = models.BooleanField(default=True, db_index=True, help_text="Uncheck to hide this comment without deleting it.")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]
        indexes = [models.Index(fields=["post", "is_visible", "created_at"], name="astragram_p_post_id_62bb25_idx")]

    def __str__(self):
        return f"Comment by {self.user} on post #{self.post_id}"


class Message(models.Model):
    """Direct messages are stored in the database and polled without extra infrastructure."""
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="sent_messages")
    recipient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="received_messages")
    text = models.CharField(max_length=1000)
    is_read = models.BooleanField(default=False, db_index=True)
    read_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["created_at"]
        indexes = [models.Index(fields=["sender", "recipient", "created_at"], name="astragram_m_sender_78e6a5_idx"), models.Index(fields=["recipient", "is_read", "created_at"], name="astragram_m_recipie_1c72d4_idx")]

    def mark_read(self):
        if not self.is_read:
            self.is_read = True
            self.read_at = timezone.now()
            self.save(update_fields=["is_read", "read_at"])
