from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("astragram", "0001_initial")]
    operations = [
        migrations.AddField(model_name="post", name="is_visible", field=models.BooleanField(db_index=True, default=True, help_text="Uncheck to hide this post from the public Astragram feed without deleting it.")),
        migrations.AddField(model_name="post", name="is_pinned", field=models.BooleanField(db_index=True, default=False, help_text="Pinned posts appear first in the public feed.")),
        migrations.AddField(model_name="comment", name="is_visible", field=models.BooleanField(db_index=True, default=True, help_text="Uncheck to hide this comment without deleting it.")),
        migrations.AddField(model_name="message", name="is_read", field=models.BooleanField(db_index=True, default=False)),
        migrations.AddField(model_name="message", name="read_at", field=models.DateTimeField(blank=True, null=True)),
        migrations.AddIndex(model_name="post", index=models.Index(fields=["is_visible", "-is_pinned", "-created_at"], name="astragram_p_visibl_7fda25_idx")),
        migrations.AddIndex(model_name="comment", index=models.Index(fields=["post", "is_visible", "created_at"], name="astragram_p_post_id_62bb25_idx")),
        migrations.AddIndex(model_name="message", index=models.Index(fields=["sender", "recipient", "created_at"], name="astragram_m_sender_78e6a5_idx")),
        migrations.AddIndex(model_name="message", index=models.Index(fields=["recipient", "is_read", "created_at"], name="astragram_m_recipie_1c72d4_idx")),
        migrations.AlterField(model_name="message", name="created_at", field=models.DateTimeField(auto_now_add=True, db_index=True)),
        migrations.AlterModelOptions(name="post", options={"ordering": ["-is_pinned", "-created_at"]}),
        migrations.AlterUniqueTogether(name="like", unique_together=set()),
        migrations.AddConstraint(model_name="like", constraint=models.UniqueConstraint(fields=("post", "user"), name="unique_astragram_like_per_user")),
        migrations.AddIndex(model_name="like", index=models.Index(fields=["post", "created_at"], name="astragram_l_post_id_4e6d2a_idx")),
    ]
