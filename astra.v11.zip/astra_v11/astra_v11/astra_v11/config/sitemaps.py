"""
Sitemap definitions for SEO. Submit /sitemap.xml to Google Search Console to help Google discover eligible public URLs. A sitemap does not guarantee crawling or indexing.
"""

from django.contrib.sitemaps import Sitemap
from django.urls import reverse

from newsroom.models import Article


class StaticViewSitemap(Sitemap):
    """Every fixed public page on the site."""

    changefreq = "weekly"

    def items(self):
        return [
            "index",
            "astra_ai",
            "astragram:feed",
            "newsroom:list",
            "music:list",
            "gallery:list",
            "events:list",
            "awards:leaderboard",
            "minigames:list",
            "astra_clock",
            "about_us",
            "support",
            "help_center",
            "terms",
            "privacy",
        ]

    def location(self, item):
        return reverse(item)

    def priority(self, item):
        if item == "index":
            return 1.0
        if item in ("newsroom:list", "astra_ai", "astragram:feed"):
            return 0.8
        return 0.6


class ArticleSitemap(Sitemap):
    """Every published Astra News post, article and project gets its own entry."""

    changefreq = "monthly"

    def items(self):
        return Article.objects.filter(is_published=True)

    def lastmod(self, obj):
        return obj.created_at

    def location(self, obj):
        return obj.get_absolute_url()

    def priority(self, obj):
        return 0.7 if obj.kind != Article.Kind.NEWS else 0.5
