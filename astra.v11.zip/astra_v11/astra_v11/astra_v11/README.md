# ASTRA v11 — Expanded Functional Rebuild

This package is an expanded functional rebuild of the Astra website source. It improves the core member, social, messaging, News, AI and Django Admin workflows while retaining the project's existing Django app structure and deployed-content compatibility. It is a source-code release, not a production database or uploaded-media backup. The Mini Games app is included unchanged.

## Fix log (post-v11 review)

- **core/migrations/0003_astra_ai_history.py**: the foreign key pointed to `core.astraiconversation` (typo). The model is `AstraAIConversation`, so `python manage.py migrate` would crash. Now `core.astraaiconversation`.
- **templates/admin/astra_index.html**: the "Astra AI history" card used `perms.core.view_astraiconversation` and `admin:core_astraiconversation_changelist` (same typo), which broke the Admin home page with NoReverseMatch. Fixed to `astraaiconversation`.
- **events/admin.py**: removed `prepopulated_fields` from `CelebrationEffectAdmin`; the `key` field is a fixed choice list, so slug auto-fill could not work.
- **config/settings.py**: added `SECURE_PROXY_SSL_HEADER` when `DJANGO_SECURE=True`, so HTTPS hosts behind a proxy (PythonAnywhere) do not hit an endless SSL redirect loop.

Run these once after unpacking: `python manage.py check`, `python manage.py migrate`, `python manage.py test`.

## What changed in v11

### Login, registration and privacy
- New registrations require an affirmative Terms & Conditions checkbox and acknowledgement of the Privacy Policy. The accepted Terms version, Privacy version and timestamp are stored in `LegalAcceptance`.
- Google and GitHub new-account registration passes through the same consent gate; existing linked social accounts can still sign in.
- The legal pages are `/terms/` and `/privacy/`; both are linked from the registration area and footer. Their text is a practical site-policy draft and **must be reviewed by the site owner for the actual hosting, email, OAuth, retention and legal setup before public launch**. It is not legal advice.
- Policy versions are configured with `ASTRA_TERMS_VERSION` and `ASTRA_PRIVACY_VERSION`. Increment these values when the respective policy changes, so a new acceptance version is recorded.

### Astragram management
- Existing posts/comments are retained. Administrators can hide or restore posts and comments without deleting them, and pin/unpin posts from Django Admin.
- Admin quick actions link directly to post moderation, comment review, and message oversight. Direct messages remain visible only through the relevant signed-in conversation and authorized admin tools.
- Messages track `is_read` and `read_at`; opening a conversation or receiving new messages in its active poll marks incoming messages as read. The inbox shows unread totals.
- The existing posting, likes, comments, inbox and chat flows are retained. No new third-party messaging service is required.

### Astra Rank — kept separate from Astra Awards
- Rank proof uploads stay pending until an administrator approves them. Category points are defined in `rank/models.py`; only approved submissions count.
- The first-place timeline stores each continuous streak. It is synchronized after admin approval/rejection and when the Rank page loads. When the leader changes, the previous streak is closed. If a previous leader later returns to first place, a new streak begins.
- Rank's special prizes are only for the **quarterly** and **yearly** first-place holder. These are records in `RankPeriodPrize`, separate from Awards prizes. A winner may reveal their prize once from the Rank page.

### Astra Awards — activity points and period trophies
- Awards competition points are earned from activity: published posts (10 points, up to three eligible posts per person per day), received likes (2), first qualifying comment from another member on a post (3), and approved Rank achievements (their approved Rank category value).
- Activity-based Rank points are synchronized into Awards once per approved submission. They are a source of Awards score, not a second Rank score bonus.
- Daily, weekly, monthly, quarterly and yearly Awards periods can produce trophy records. Winning a period gives an award only; **the act of winning never adds extra competition points**. Tied highest scorers are each recorded as winners.
- The eligible winner sees a server-authorized, one-time reveal button. A gold confetti reveal is shown, the award and claim date are saved, and the claimed trophy appears in the profile and Awards collection.
- Completed periods are finalized when the Awards page is opened or by running the scheduled management command described below.

### Astra Events — celebrations, not event registration
- Events remain a configurable celebration page. Admins set title, greeting, dates, theme/color and choose up to three effects from the effect library.
- The library includes snowfall, Santa fly-by, decorative light bursts, golden sparks, confetti, garlands, floating stars and lantern glow. These are visual effects only.
- Visitors can choose between live events and upcoming events starting within seven days. There is no attendee/ticket/registration workflow.

### SEO, AI discovery and responsiveness
- `/sitemap.xml` lists public, intended-to-be-indexed pages and published articles; account, admin, message and private Rank routes are excluded. `/robots.txt` points to the sitemap and keeps private routes disallowed.
- OpenAI search crawling and model-training crawling have separate controls: `ALLOW_OAI_SEARCHBOT` defaults to `True`; `ALLOW_GPTBOT` defaults to `False`. These controls are independent. Review the current bot documentation before changing them: <https://developers.openai.com/api/docs/bots>.
- `/llms.txt` is an optional plain-language map of public site pages. It is experimental guidance, not a standard or a promise of AI search inclusion. No sitemap, crawler setting, schema or file can guarantee indexing, citations or placement in ChatGPT/other AI answers.
- The site adds safe responsive CSS for narrow and wide screens while leaving the existing desktop design as the base. The changes avoid broad redesigns; visual browser verification still needs to be performed on the deployed site at representative mobile/tablet/desktop widths.

### Footer and visible version
- Only the social links in the footer were changed/confirmed. Existing internal navigation links were not replaced.
- LinkedIn: `https://www.linkedin.com/in/arya-ghavami-4ba5a23a3?utm_source=share_via&utm_content=profile&utm_medium=member_android`
- Astra Land: `https://astrarya11.carrd.co`
- GitHub: `https://github.com/a7rya1390-ux`
- Instagram: `https://www.instagram.com/astra_201105?igsh=aWtrcmJ5N283N3Vp`
- X: `https://x.com/ASTRArya11`
- Telegram: `https://t.me/Astra_1105`
- The footer and About page show **Astra v11**. There is no AG9 link placeholder; add the real link after it is provided.

## Database continuity and safe upgrades

### First v10 → v11 deployment

The supplied ZIP contains the website source only; it does not contain the live PythonAnywhere database or uploaded media. Before replacing the running site, make a dated backup of the live v10 database and media directory. Copy the live database and media to stable locations (or keep their existing persistent locations), set `DJANGO_DB_PATH` and `DJANGO_MEDIA_ROOT` to those exact locations, and deploy v11 against that same database. Do not point the new site at a fresh empty database unless you have independently confirmed that is what you intend. Run `python manage.py migrate` only after the backup is verified.

The release uses additive Django migrations. Keep both the database and uploaded media outside disposable code-release directories by setting `DJANGO_DB_PATH` and `DJANGO_MEDIA_ROOT` to stable absolute paths. Create their parent directories and ensure the hosting account can read and write them. For version upgrades (v11 to v12 and later):

1. Stop/reload the web app as appropriate for the host.
2. Back up the current database file and the entire `media/` folder. Keep a dated copy away from the live release folder.
3. Deploy the new code without replacing or deleting the stable database or media directory.
4. Confirm `DJANGO_DB_PATH` and `DJANGO_MEDIA_ROOT` still point at the same persistent locations.
5. Run `python manage.py migrate`, then `python manage.py collectstatic --noinput`, then reload the web app.
6. Verify login, Astragram, Rank, Awards, Events, News, Music, Gallery and Mini Games. Keep the backup until the release is confirmed stable.

**Never delete `db.sqlite3`, the configured external database file, the configured media directory, or migration history during a routine release.** A migration adds/changes schema while existing rows are preserved; do not replace the database with the one in a source archive. The supplied v10 archive has no production database, so no live records were changed during this build.

### One-superuser rotation (production-only, explicit command)

The supplied archive does not include the live database, so it is impossible to identify or delete old production superusers from this build. After deploying v11 and backing up the production database, run:

```bash
python manage.py rotate_astra_superuser
```

The command asks for a new username, email and password, validates the password, checks whether old superuser accounts own related content, then asks for the exact confirmation phrase `ROTATE-ASTRA-SUPERUSER`. It creates the replacement first and deletes the older superuser accounts only if the safety check passes. The profile row created automatically for each deleted account is removed with that account; if it finds other related records (for example, posts, consent history, submissions or Rank history), it stops instead of cascade-deleting that content. Review/reassign those records manually and rerun. It intentionally does not invent or print credentials. Verify the new account can sign in to `/admin/` and confirm exactly one superuser remains. Keep the backup until verified.

## Django Admin management

- **Astragram:** Admin → Astragram Posts / Comments / Messages. Use visibility and pin controls/actions to moderate without destroying content.
- **Rank:** Admin → Rank Submissions. Approve/reject proof uploads; approved points feed Awards once. Quarterly/yearly Rank prizes are available under Rank Period Prizes.
- **Awards:** Admin → Awards Competition Awards. Generated records are read-only except title/icon/image display details; claims are recorded by the site.
- **Events:** Admin → Events and Celebrations → Events; edit the Celebration Effect Library separately. Each event may use a maximum of three enabled effects.
- The Admin homepage includes quick links for these management workflows.
- The competition and Rank areas include original Astra trophy/medal SVG artwork as defaults; admins can upload an individual award image when a particular prize needs its own design.

## Google Search Console and AI discoverability setup

1. Verify control of the production domain in <https://search.google.com/search-console> (DNS verification is usually the most robust; HTML tag is also supported by the site's `GOOGLE_SITE_VERIFICATION` setting).
2. Set `GOOGLE_SITE_VERIFICATION` in the hosting environment if using HTML-tag verification, then reload and complete verification.
3. In Search Console → Sitemaps, submit `https://YOUR-DOMAIN/sitemap.xml`. The sitemap helps discovery but Google decides whether and when to crawl/index each URL.
4. Use URL Inspection to request a crawl of the homepage or important public page, then monitor Pages/Indexing. A request is not a guarantee.
5. Check `/robots.txt` on the real domain. Set `ALLOW_OAI_SEARCHBOT=True` to allow ChatGPT Search crawling. Set `ALLOW_GPTBOT=True` only if you separately choose to allow GPTBot; this is not required to allow OAI-SearchBot.
6. The site also exposes `/llms.txt` as optional reference material. It does not guarantee an AI platform will fetch, index or cite the site.

## OAuth configuration

Set the provider keys in the hosting environment (do not commit secrets). In Google Cloud Console or GitHub OAuth settings, use the real production callback URLs:

- Google: `https://YOUR-DOMAIN/accounts/google/login/callback/`
- GitHub: `https://YOUR-DOMAIN/accounts/github/login/callback/`

```bash
GOOGLE_OAUTH_CLIENT_ID=...
GOOGLE_OAUTH_CLIENT_SECRET=...
GITHUB_OAUTH_CLIENT_ID=...
GITHUB_OAUTH_CLIENT_SECRET=...
DJANGO_HTTP_PROTOCOL=https
```

New social registrations must accept the Astra policies first. Existing linked social accounts can continue to sign in.

## Setup / local checks

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py check
python manage.py test
python manage.py runserver
```

Useful deployment environment variables include `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=False`, `DJANGO_ALLOWED_HOSTS`, `DJANGO_TIME_ZONE` (for example `Asia/Tehran`), `DJANGO_DB_PATH`, `DJANGO_MEDIA_ROOT`, `DJANGO_HTTP_PROTOCOL=https`, `GOOGLE_SITE_VERIFICATION`, `BING_SITE_VERIFICATION`, `ALLOW_OAI_SEARCHBOT`, `ALLOW_GPTBOT`, `ASTRA_TERMS_VERSION`, and `ASTRA_PRIVACY_VERSION`.

To finalize closed Awards periods without waiting for a visitor to open the page, run this command on a schedule (for example, daily):

```bash
python manage.py close_competitions
```

The command creates missing DailyChampion/MonthlyChampion history, durable daily/weekly/monthly/quarterly/yearly CompetitionAward records, and separate quarterly/yearly RankPeriodPrize records. It does not award bonus points for winning.

## Validation status and limitations

- Python syntax compilation: passed (`python -m compileall`).
- JavaScript syntax checks: passed (`node --check` for all project JavaScript files).
- Source archive and project tree were compared/copied into a separate v11 folder; the original v10 archive was not edited.
- The build environment used for packaging did not have Django or django-allauth installed. Therefore `python manage.py check`, migrations against SQLite, and Django's automated test suite could **not** be executed here. Automated tests have been added/updated for the new workflows, but they must be run in the project's installed virtual environment.
- A production database and browser/hosting credentials were not included. No live superuser was removed, no production database was migrated, and no deployed-page visual testing was possible. After deployment, run the checks above and verify the site at common widths (360, 390, 768, 1024, 1366 and 1920 pixels).

## Astra v11 expanded rebuild — important functional fixes

This rebuild goes beyond the earlier partial v11 package. It adds the missing functional work in the social, messaging, News, AI and administration areas:

### Member profiles and social graph
- Every member has a public profile at `/members/<username>/` and a private edit page at `/profile/`.
- Profile pages show post, follower, following, Awards and Rank prize counts; the first follower/following entries link to other public profiles.
- Signed-in members can follow/unfollow another member and open a direct message from that member's profile.
- Astragram post author avatars/names and comment author names open the corresponding public profile.
- Existing accounts without a Profile row receive one through the added data migration.

### Direct messages
- The Messages link is available in the signed-in navigation and Astragram feed.
- Members can search for another username from the inbox and open a conversation, including an empty first conversation.
- Sending returns a clear success/error result, new messages are polled, duplicates are guarded against, and incoming messages are marked read when the conversation is opened or refreshed.
- Conversations remain participant-scoped. The Django Admin has read-only message oversight for authorized staff; it is not a public inbox.

### Astra News Trending
- The old fixed hashtag chips are removed.
- Trending topics are calculated from hashtags in recently published News/Articles and public Astragram posts, with the last-30-days window.
- Clicking a topic searches Astra News for that term.
- News detail views increment a persisted view counter; the News page shows popular news items ordered by views and recency.
- The counter is an on-site page-view count, not unique visitors or an analytics-grade metric.

### Astra AI
- The chat UI has been rebuilt with usable recent conversation navigation, prompt suggestions, a composer, send/error states and mobile layout.
- Signed-in members' conversation and message history is saved in the Django database and can be reopened. Anonymous chat is not persisted.
- A configurable OpenAI-compatible Chat Completions endpoint can power the assistant. Server environment variables are `ASTRA_AI_API_KEY`, `ASTRA_AI_BASE_URL` (default `https://api.openai.com/v1`), `ASTRA_AI_MODEL` (default `gpt-4o-mini`) and optional `ASTRA_AI_TIMEOUT`.
- Without a server-side API key, Astra runs its existing built-in knowledge/rule mode and clearly labels the mode in the interface. That fallback is not a full generative model. Configure a provider before describing the live model as connected.
- Never put the provider key in HTML, JavaScript, GitHub, or the ZIP. Use the hosting platform's environment-variable settings. Review the provider's current privacy and age requirements before enabling it publicly.

### Django Admin images and usability
- Astragram Post change pages and lists now show a thumbnail/preview of uploaded post images.
- Rank Submission change pages and lists now show the proof image and a larger preview.
- Profile avatars and banners and News article images also have previews.
- `MEDIA_URL` now defaults to the absolute `/media/` path; the earlier relative `media/` path could resolve incorrectly inside `/admin/...` pages.
- On PythonAnywhere or another production host, configure a `/media/` static mapping that points to the exact persistent `DJANGO_MEDIA_ROOT`. The Django `DEBUG` development media route is not a production media server.

### Rank field length
- Rank Submission `category` storage is expanded from 30 to 64 characters with an additive migration. Existing category values remain unchanged. This avoids a future internal category identifier being rejected solely due to the old short field size.

## Updated deployment steps

1. Back up the production database and entire uploaded media directory before uploading this rebuild. Keep the backups outside the code release folder.
2. Upload/extract the ZIP to a new code folder. Do not overwrite or delete the production database or media folder.
3. Make sure `DJANGO_DB_PATH` still points to the existing persistent production database and `DJANGO_MEDIA_ROOT` still points to the existing persistent media directory.
4. Configure the host's `/media/` mapping to the same media directory. Keep the Django setting `DJANGO_MEDIA_URL=/media/` unless the host uses a different absolute media URL.
5. Install requirements in the project's virtual environment and run:

   ```bash
   python manage.py migrate
   python manage.py check
   python manage.py collectstatic --noinput
   ```

6. Reload the web app, then verify login, profile, follow/unfollow, Astragram author profile links, inbox search, direct-message send/receive, News trending, Astra AI, Rank proof previews and Astragram image previews.
7. The production superuser accounts cannot be deleted by uploading a source ZIP. After taking a verified backup and confirming which production database is configured, run the interactive command below on the server:

   ```bash
   python manage.py rotate_astra_superuser
   ```

   It creates the new superuser first, requires the exact confirmation phrase, and removes older superusers only if the command's record-safety checks pass. If it stops because an older superuser owns posts, Rank records, messages, or other content, reassign/review those records instead of bypassing the protection. Verify the new admin login and that exactly one superuser remains. Do not send the password in chat.

8. To enable generative Astra AI, set the API key and model through host environment variables and reload. Without those variables, the site intentionally remains in Knowledge mode.

## Verification status for this archive

- Python source files were compiled with `compileall` successfully.
- JavaScript files passed `node --check`.
- ZIP integrity and required source/migration files were checked.
- Full Django system checks, migration planning, ORM integration tests, browser tests, production Admin image delivery, real message delivery between two deployed accounts, and calls to an external AI provider could not be executed in this build environment because Django dependencies could not be installed here and no production database/hosting credentials or provider key were supplied. Run the commands above in the project's virtual environment before deploying.
