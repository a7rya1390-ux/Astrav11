from django.conf import settings
from django.utils import timezone

from .models import LegalAcceptance


class ClearSocialConsentAfterLoginMiddleware:
    """Persist a short-lived consent after OAuth success and clear it safely."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        consent = request.session.get("astra_legal_consent")
        if not isinstance(consent, dict):
            return response

        try:
            accepted_at = float(consent.get("accepted_at", 0))
        except (TypeError, ValueError):
            accepted_at = 0
        is_current = (
            consent.get("terms_version") == settings.ASTRA_TERMS_VERSION
            and consent.get("privacy_version") == settings.ASTRA_PRIVACY_VERSION
            and 0 <= timezone.now().timestamp() - accepted_at <= 900
        )
        authenticated = getattr(request, "user", None) is not None and request.user.is_authenticated

        if authenticated and is_current:
            LegalAcceptance.objects.get_or_create(
                user=request.user,
                terms_version=consent["terms_version"],
                privacy_version=consent["privacy_version"],
            )
            request.session.pop("astra_legal_consent", None)
        elif not is_current:
            # Keep valid consent through provider redirects and any intermediate
            # allauth signup step; save_user clears it after account creation.
            request.session.pop("astra_legal_consent", None)
        return response
