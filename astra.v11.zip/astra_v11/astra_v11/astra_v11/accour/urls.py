from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("profile/", views.profile_view, name="profile"),
    path("members/<str:username>/follow/", views.toggle_follow, name="toggle_follow"),
    path("members/<str:username>/", views.public_profile, name="public_profile"),
    path("terms/", views.terms, name="terms"),
    path("privacy/", views.privacy, name="privacy"),
    path("social-consent/<str:provider>/", views.social_login_consent, name="social_login_consent"),
    path("social-unavailable/<str:provider>/", views.social_unavailable, name="social_unavailable"),
]
