from django.apps import AppConfig


class AccourConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "accour"

    def ready(self):
        from . import signals  # noqa: F401
