from django.contrib import admin
from django.utils.html import format_html

from .models import Follow, LegalAcceptance, Profile


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "is_verified", "has_avatar", "has_banner")
    list_editable = ("is_verified",)
    list_filter = ("is_verified",)
    search_fields = ("user__username", "user__email", "bio")
    list_select_related = ("user",)
    readonly_fields = ("avatar_preview", "banner_preview")
    fields = ("user", "is_verified", "avatar", "avatar_preview", "banner", "banner_preview", "bio")

    @admin.display(boolean=True, description="Has avatar")
    def has_avatar(self, obj): return bool(obj.avatar)

    @admin.display(boolean=True, description="Has banner")
    def has_banner(self, obj): return bool(obj.banner)

    @admin.display(description="Avatar preview")
    def avatar_preview(self, obj):
        if not obj or not obj.avatar: return "No avatar uploaded"
        return format_html('<img src="{}" style="width:110px;height:110px;object-fit:cover;border-radius:50%" />', obj.avatar.url)

    @admin.display(description="Banner preview")
    def banner_preview(self, obj):
        if not obj or not obj.banner: return "No banner uploaded"
        return format_html('<img src="{}" style="max-width:460px;max-height:180px;object-fit:cover;border-radius:9px" />', obj.banner.url)


@admin.register(Follow)
class FollowAdmin(admin.ModelAdmin):
    list_display = ("follower", "following", "created_at")
    search_fields = ("follower__username", "following__username")
    list_filter = ("created_at",)
    readonly_fields = ("follower", "following", "created_at")
    date_hierarchy = "created_at"
    def has_add_permission(self, request): return False


@admin.register(LegalAcceptance)
class LegalAcceptanceAdmin(admin.ModelAdmin):
    list_display = ("user", "terms_version", "privacy_version", "accepted_at")
    search_fields = ("user__username", "user__email", "terms_version", "privacy_version")
    list_filter = ("terms_version", "privacy_version", "accepted_at")
    readonly_fields = ("user", "terms_version", "privacy_version", "accepted_at")
    date_hierarchy = "accepted_at"
    def has_add_permission(self, request): return False
    def has_change_permission(self, request, obj=None): return False
